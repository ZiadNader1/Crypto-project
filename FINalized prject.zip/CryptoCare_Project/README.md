# CryptoCare — Secure Healthcare Portal

A fully from-scratch cryptographic system implementing symmetric ciphers (XTEA, IDEA),
asymmetric cryptography (ElGamal), a PKI Certificate Authority, and a post-quantum
Ring-LWE scheme — integrated into a realistic healthcare portal scenario.

---

## Algorithms Implemented

| Module | Algorithm | Type | Key Size | Block |
|--------|-----------|------|----------|-------|
| A-1 | **XTEA** | Symmetric | 128-bit | 64-bit |
| A-2 | **IDEA** | Symmetric | 128-bit | 64-bit |
| B   | **ElGamal** | Asymmetric | ≥256-bit prime | variable |
| Bonus | **Ring-LWE** | Post-Quantum | N=16, q=97 | bit-by-bit |

**No external cryptographic libraries used.** Only Python standard library
(`os`, `struct`, `random`, `time`, `json`) plus `pytest`/`psutil` for testing.

---

## Project Structure

```
project/
├── main.py                          # Full demo (run this)
├── requirements.txt
├── src/
│   ├── utils/math_utils.py          # Miller-Rabin, extended GCD, hash
│   ├── symmetric/
│   │   ├── xtea.py                  # XTEA cipher (CBC mode)
│   │   └── idea.py                  # IDEA cipher (CBC mode)
│   ├── asymmetric/
│   │   └── elgamal.py               # ElGamal encrypt/decrypt + signatures
│   ├── pqc/
│   │   └── lwe.py                   # Ring-LWE post-quantum encryption
│   ├── ca/
│   │   └── certificate_authority.py # CA: issue, verify, revoke certs
│   └── app/
│       ├── secure_session.py        # TLS-style handshake & session
│       └── healthcare_portal.py     # Integrated business scenario
├── tests/
│   ├── test_xtea.py
│   ├── test_idea.py
│   ├── test_elgamal.py
│   ├── test_ca.py
│   └── test_integration.py
└── benchmarks/
    └── performance.py               # Timing + memory + comm. cost
```

---

## Setup

```bash
# Requires Python 3.10+
pip install -r requirements.txt
```

---

## Run the Demo

```bash
python main.py
```

With performance benchmarks:

```bash
python main.py --bench
```

---

## Run Tests

```bash
pytest tests/ -v
```

With coverage report:

```bash
pytest tests/ -v --cov=src --cov-report=term-missing
```

---

## Run Benchmarks Only

```bash
python benchmarks/performance.py
```

---

## AI Usage Declaration

AI tools (Claude) were used for:
- Code suggestions, syntax help, and debugging
- Structuring the project layout

All cryptographic algorithm logic is based on original published specifications:
- XTEA: Wheeler & Needham (1997)
- IDEA: Lai & Massey (1991)
- ElGamal: ElGamal (1985)
- Ring-LWE: Lyubashevsky, Peikert & Regev (2010)

No AI was used to generate the project report.

---

## Handwritten Verification

See report appendix for handwritten worked examples of:
1. **XTEA** — one round trace with K=[1,2,3,4], v0=1, v1=2
2. **IDEA** — group operations (⊗, ⊞) and one round with small values
3. **ElGamal** — encrypt/decrypt with p=23, g=5, x=6, m=10

The `main.py` demo prints these small-value traces to the console.

---

## Security Notes

- Key sizes in demo use 128–256-bit ElGamal primes for speed.
  Production systems should use **≥2048-bit** primes.
- The custom hash function (`simple_hash`) is for demonstration only.
  Production systems should use SHA-256 or BLAKE3.
- Ring-LWE parameters (N=16, q=97) are educational toys.
  Use CRYSTALS-Kyber (NIST standard) for real post-quantum security.
- CBC mode is used for simplicity; production prefers AES-GCM (authenticated).

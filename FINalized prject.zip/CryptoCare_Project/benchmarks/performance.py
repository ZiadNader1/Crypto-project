"""
Performance Benchmarks
======================
Measures computation cost (time, memory) and communication cost (ciphertext size)
for all cryptographic algorithms implemented in this project.

Metrics collected
-----------------
Computation cost
    • Wall-clock time (seconds)  — averaged over N_RUNS repetitions
    • Peak memory delta (KB)     — via psutil process memory sampling

Communication cost
    • Plaintext size  (bytes)
    • Ciphertext size (bytes)
    • Expansion ratio = ciphertext / plaintext

Big-O complexity summary (printed alongside measurements)
----------------------------------------------------------
Algorithm          Encrypt          Decrypt        Key gen
---------          -------          -------        -------
XTEA (n bytes)     O(n)             O(n)           O(1)
IDEA (n bytes)     O(n)             O(n)           O(1)
ElGamal (int)      O(log²p)         O(log²p)       O(bits³)
LWE  (n bytes)     O(N²·8·n)        O(N²·8·n)      O(N²)
"""

from __future__ import annotations

import os
import sys
import time
from typing import Callable

try:
    import psutil
    _HAS_PSUTIL = True
except ImportError:
    _HAS_PSUTIL = False

# Ensure project root is on path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.symmetric.xtea import XTEACipher, generate_key as xtea_key
from src.symmetric.idea import IDEACipher, generate_key as idea_key
from src.asymmetric.elgamal import generate_keys, encrypt_int, decrypt_int, sign, verify
from src.pqc.lwe import generate_keys as lwe_keys, encrypt_bytes, decrypt_bytes


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

N_RUNS = 5         # repetitions per benchmark
SIZES  = [64, 256, 1024, 4096]   # plaintext sizes in bytes


def _mem_kb() -> float:
    if not _HAS_PSUTIL:
        return 0.0
    proc = psutil.Process(os.getpid())
    return proc.memory_info().rss / 1024


def _bench(fn: Callable, runs: int = N_RUNS) -> tuple[float, float]:
    """Return (mean_seconds, mem_delta_kb) for calling fn() `runs` times."""
    mem_before = _mem_kb()
    start = time.perf_counter()
    for _ in range(runs):
        fn()
    elapsed = (time.perf_counter() - start) / runs
    mem_after = _mem_kb()
    return elapsed, max(0.0, mem_after - mem_before)


def _bar(value: float, max_val: float, width: int = 30) -> str:
    filled = int(width * value / max_val) if max_val > 0 else 0
    return "[" + "█" * filled + "░" * (width - filled) + "]"


def _header(title: str) -> None:
    print("\n" + "=" * 70)
    print(f"  {title}")
    print("=" * 70)


def _row(label: str, time_s: float, mem_kb: float, pt: int = 0, ct: int = 0) -> None:
    ratio = f"{ct/pt:.2f}x" if pt > 0 else "n/a"
    print(
        f"  {label:<28} "
        f"{time_s*1000:>8.3f} ms  "
        f"{mem_kb:>8.1f} KB  "
        f"{pt:>6} B → {ct:>6} B  ({ratio})"
    )


# ---------------------------------------------------------------------------
# XTEA benchmarks
# ---------------------------------------------------------------------------

def bench_xtea() -> dict:
    _header("XTEA — Extended Tiny Encryption Algorithm")
    print(f"  {'Operation':<28} {'Time (ms)':>9}  {'ΔMem (KB)':>9}  {'Communication cost'}")
    print("  " + "-" * 65)
    results = {}

    for size in SIZES:
        plaintext = os.urandom(size)
        key = xtea_key()
        cipher = XTEACipher(key)
        ct = cipher.encrypt(plaintext)

        t_enc, m_enc = _bench(lambda: cipher.encrypt(plaintext))
        t_dec, m_dec = _bench(lambda: cipher.decrypt(ct))

        _row(f"XTEA encrypt ({size:>4} B)", t_enc, m_enc, size, len(ct))
        _row(f"XTEA decrypt ({size:>4} B)", t_dec, m_dec, len(ct), size)
        results[size] = {"enc_ms": t_enc*1000, "dec_ms": t_dec*1000,
                         "ct_size": len(ct), "ratio": len(ct)/size}

    print(f"\n  Big-O: O(n) encrypt & decrypt, O(1) key schedule")
    print(f"  Block size: 64-bit | Key: 128-bit | Rounds: 64 | Mode: CBC")
    return results


# ---------------------------------------------------------------------------
# IDEA benchmarks
# ---------------------------------------------------------------------------

def bench_idea() -> dict:
    _header("IDEA — International Data Encryption Algorithm")
    print(f"  {'Operation':<28} {'Time (ms)':>9}  {'ΔMem (KB)':>9}  {'Communication cost'}")
    print("  " + "-" * 65)
    results = {}

    for size in SIZES:
        plaintext = os.urandom(size)
        key = idea_key()
        cipher = IDEACipher(key)
        ct = cipher.encrypt(plaintext)

        t_enc, m_enc = _bench(lambda: cipher.encrypt(plaintext))
        t_dec, m_dec = _bench(lambda: cipher.decrypt(ct))

        _row(f"IDEA encrypt ({size:>4} B)", t_enc, m_enc, size, len(ct))
        _row(f"IDEA decrypt ({size:>4} B)", t_dec, m_dec, len(ct), size)
        results[size] = {"enc_ms": t_enc*1000, "dec_ms": t_dec*1000,
                         "ct_size": len(ct), "ratio": len(ct)/size}

    print(f"\n  Big-O: O(n) encrypt & decrypt, O(1) key schedule")
    print(f"  Block size: 64-bit | Key: 128-bit | Rounds: 8+1 | Mode: CBC")
    return results


# ---------------------------------------------------------------------------
# ElGamal benchmarks
# ---------------------------------------------------------------------------

def bench_elgamal() -> dict:
    _header("ElGamal — Discrete Logarithm Public-Key Cryptosystem")
    print(f"  {'Operation':<28} {'Time (ms)':>9}  {'ΔMem (KB)':>9}")
    print("  " + "-" * 50)
    results = {}

    for bits in [128, 256]:
        print(f"\n  --- {bits}-bit prime ---")

        t_kg, m_kg = _bench(lambda: generate_keys(bits=bits), runs=3)
        priv = generate_keys(bits=bits)
        pub = priv.public_key
        m = 12345

        ct = encrypt_int(m, pub)
        t_enc, m_enc = _bench(lambda: encrypt_int(m, pub))
        t_dec, m_dec = _bench(lambda: decrypt_int(ct, priv))
        msg = b"authentication token for benchmarking"
        sig = sign(msg, priv)
        t_sign, m_sign = _bench(lambda: sign(msg, priv))
        t_verify, m_verify = _bench(lambda: verify(msg, sig, pub))

        # Key sizes in bytes
        p_bytes = (priv.p.bit_length() + 7) // 8
        print(f"  {'Key generation':<28} {t_kg*1000:>8.1f} ms  {m_kg:>8.1f} KB")
        print(f"  {'Encrypt (int)':<28} {t_enc*1000:>8.3f} ms  {m_enc:>8.1f} KB")
        print(f"  {'Decrypt (int)':<28} {t_dec*1000:>8.3f} ms  {m_dec:>8.1f} KB")
        print(f"  {'Sign':<28} {t_sign*1000:>8.3f} ms  {m_sign:>8.1f} KB")
        print(f"  {'Verify':<28} {t_verify*1000:>8.3f} ms  {m_verify:>8.1f} KB")
        print(f"  Public key size: {p_bytes} B (p) + {p_bytes} B (y) = {2*p_bytes} B")
        print(f"  Ciphertext size: {p_bytes} B (c1) + {p_bytes} B (c2) = {2*p_bytes} B")

        results[bits] = {
            "keygen_ms": t_kg*1000, "enc_ms": t_enc*1000,
            "dec_ms": t_dec*1000, "pk_bytes": 2*p_bytes,
            "ct_bytes": 2*p_bytes,
        }

    print(f"\n  Big-O: O(bits³) keygen, O(log²p) encrypt/decrypt/sign/verify")
    return results


# ---------------------------------------------------------------------------
# LWE (PQC) benchmarks
# ---------------------------------------------------------------------------

def bench_lwe() -> dict:
    _header("Ring-LWE — Post-Quantum Encryption (Bonus)")
    print(f"  {'Operation':<28} {'Time (ms)':>9}  {'ΔMem (KB)':>9}  {'Comm. cost'}")
    print("  " + "-" * 60)
    results = {}

    priv = lwe_keys()
    pub = priv.pub

    for size in [1, 4, 16]:
        data = os.urandom(size)
        ct = encrypt_bytes(data, pub)
        ct_size = len(ct.u_polys) * 16 + len(ct.v_scalars) * 4   # rough estimate

        t_enc, m_enc = _bench(lambda: encrypt_bytes(data, pub))
        t_dec, m_dec = _bench(lambda: decrypt_bytes(ct, priv))

        _row(f"LWE  encrypt ({size:>4} B)", t_enc, m_enc, size, ct_size)
        _row(f"LWE  decrypt ({size:>4} B)", t_dec, m_dec, ct_size, size)
        results[size] = {"enc_ms": t_enc*1000, "dec_ms": t_dec*1000}

    print(f"\n  Big-O: O(N²·8·n) encrypt & decrypt")
    print(f"  Params: N=16, q=257 (educational toy params — not production-secure)")
    print(f"  Production (Kyber-512): N=256, q=3329, NTT optimised → O(N log N·n)")
    return results


# ---------------------------------------------------------------------------
# Comparison table
# ---------------------------------------------------------------------------

def print_comparison(xtea_r: dict, idea_r: dict, eg_r: dict, lwe_r: dict) -> None:
    _header("ALGORITHM COMPARISON SUMMARY (1 KB plaintext)")

    print(f"\n  {'Algorithm':<20} {'Enc (ms)':>10} {'Dec (ms)':>10} "
          f"{'Key gen (ms)':>13} {'CT size':>10} {'Security basis'}")
    print("  " + "-" * 78)

    size = 1024
    eg128 = eg_r.get(128, {})

    rows = [
        ("XTEA (128-bit)",  xtea_r[size]["enc_ms"], xtea_r[size]["dec_ms"],
         0.001, f"{xtea_r[size]['ct_size']} B", "Feistel / confusion+diffusion"),
        ("IDEA (128-bit)",  idea_r[size]["enc_ms"], idea_r[size]["dec_ms"],
         0.001, f"{idea_r[size]['ct_size']} B", "Mixed group operations"),
        ("ElGamal (128-bit)", eg128.get("enc_ms", 0), eg128.get("dec_ms", 0),
         eg128.get("keygen_ms", 0), f"{eg128.get('ct_bytes',0)} B", "Discrete log problem"),
        ("Ring-LWE (PQC)",  lwe_r.get(1,{}).get("enc_ms",0), lwe_r.get(1,{}).get("dec_ms",0),
         0.1, "N/A", "Learning With Errors"),
    ]
    for name, enc, dec, kg, ct_sz, basis in rows:
        print(f"  {name:<20} {enc:>10.3f} {dec:>10.3f} {kg:>13.1f} {ct_sz:>10}  {basis}")

    print("""
  Notes
  -----
  • XTEA and IDEA are symmetric ciphers — encrypt/decrypt operate on the
    same 128-bit key.  Key generation is trivial (generate 16 random bytes).
  • ElGamal is an asymmetric cipher.  Key generation involves safe-prime
    generation which dominates cost.  Ciphertext is 2× the key size.
  • Ring-LWE ciphertext expansion is very large for small inputs (bit-per-bit
    encoding).  Kyber uses polynomial packing for much better efficiency.
  • For production use: XTEA/IDEA with 128-bit keys, ElGamal with ≥2048-bit
    primes, and standardised Kyber-512/768 for post-quantum security.
""")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def run_all() -> None:
    print("\n" + "╔" + "═" * 68 + "╗")
    print("║  CRYPTOGRAPHIC PERFORMANCE BENCHMARK SUITE" + " " * 25 + "║")
    print("║  Secure Healthcare Portal — All Algorithms" + " " * 25 + "║")
    print("╚" + "═" * 68 + "╝")

    xtea_r  = bench_xtea()
    idea_r  = bench_idea()
    eg_r    = bench_elgamal()
    lwe_r   = bench_lwe()

    print_comparison(xtea_r, idea_r, eg_r, lwe_r)


if __name__ == "__main__":
    run_all()

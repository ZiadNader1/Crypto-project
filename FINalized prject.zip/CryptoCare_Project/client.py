"""
run_client.py -- Connect a client to the secure healthcare TCP server.

Usage
-----
    python run_client.py [options]

Options
-------
    --host HOST     Server host (default: 127.0.0.1)
    --port PORT     Server TCP port (default: 9999)
    --name NAME     Client name / identity (default: Patient-Jane)
    --bits BITS     ElGamal key size in bits (default: 256)

Example
-------
    # Terminal 1:  python run_server.py
    # Terminal 2:  python run_client.py --name Doctor-Smith

The client will:
  1. Generate an ElGamal key pair locally.
  2. BOOTSTRAP -- ask the server to issue a CA-signed certificate and send
     back the CA public key (so the client can verify the server's cert).
  3. Perform a TLS-style handshake (ElGamal key exchange + mutual auth).
  4. Authenticate with Ring-LWE (PQC).
  5. Upload a sample medical record (XTEA-encrypted in transit).
  6. Download the record back and verify content integrity.
  7. Disconnect cleanly.
"""

from __future__ import annotations

import argparse
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

from src.ca.certificate_authority import CertificateAuthority
from src.network.client import NetworkClient


# ---------------------------------------------------------------------------
# Demo medical record content
# ---------------------------------------------------------------------------

DEMO_RECORD = (
    b"PATIENT: {name}\n"
    b"DOB    : 15/03/1985\n"
    b"DIAG   : Type-2 Diabetes Mellitus\n"
    b"HbA1c  : 7.2%  (target < 6.5%)\n"
    b"MEDS   : Metformin 500 mg twice daily\n"
    b"REVIEW : 3 months\n"
)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="CryptoCare -- Secure Healthcare TCP Client",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument("--host", default="127.0.0.1", help="Server host")
    p.add_argument("--port", type=int, default=9999,  help="Server TCP port")
    p.add_argument("--name", default="Patient-Jane",  help="Client identity")
    p.add_argument("--bits", type=int, default=256,   help="ElGamal key bits")
    return p.parse_args()


def main() -> None:
    args = parse_args()

    print("\n" + "=" * 65)
    print("  CryptoCare -- Secure Healthcare TCP Client")
    print(f"  Identity : {args.name}")
    print("=" * 65)

    # A stub CA whose public_key is replaced during BOOTSTRAP so the
    # client can correctly verify the server's certificate afterwards.
    stub_ca = CertificateAuthority("stub-ca")   # real init, has _priv
    stub_ca.name = "pending"
# public_key and _priv will be overwritten during BOOTSTRAP
    # stub_ca.public_key is populated inside NetworkClient._do_bootstrap()

    client = NetworkClient(
        name=args.name,
        ca=stub_ca,
        host=args.host,
        port=args.port,
        key_bits=args.bits,
        bootstrap=True,   # request cert + CA public key from the server
    )

    print(f"\n[Demo] Connecting to {args.host}:{args.port}...")
    client.connect()   # bootstrap -> handshake -> PQC auth

    # Upload a demo medical record
    record = DEMO_RECORD.replace(b"{name}", args.name.encode())

    print(f"\n{'=' * 60}")
    print("  Uploading medical record...")
    print(f"{'=' * 60}")
    path = client.upload("medical_record", record)
    print(f"[Demo] Stored at: {path}")

    # Download it back
    print(f"\n{'=' * 60}")
    print("  Downloading medical record...")
    print(f"{'=' * 60}")
    recovered = client.download(path)

    # Verify integrity
    print(f"\n{'=' * 60}")
    print("  Integrity check")
    print(f"{'=' * 60}")
    if recovered == record:
        print("  Content integrity : PASSED OK")
        print(f"  First line        : {recovered.splitlines()[0].decode()}")
    else:
        print("  Content integrity : FAILED")
        client.disconnect()
        sys.exit(1)

    client.disconnect()

    print("\n" + "=" * 65)
    print("  Client demo completed successfully")
    print("=" * 65 + "\n")


if __name__ == "__main__":
    main()

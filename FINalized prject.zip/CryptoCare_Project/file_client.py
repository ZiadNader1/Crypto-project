"""
file_client.py -- Secure File Upload Client
============================================
Lets you pick a file, choose an encryption algorithm
(XTEA, IDEA, ElGamal, or Ring-LWE), encrypts the file locally,
and sends it to the file server.

The server saves both the encrypted and decrypted copies.

Usage
-----
    python file_client.py
"""

import os
import sys
import socket
import json
import struct

sys.path.insert(0, os.path.dirname(__file__))

HOST = "127.0.0.1"
PORT = 9999


# --------------------------------------------------------------------------
# Tiny framing helpers (must match server)
# --------------------------------------------------------------------------

def send_msg(sock, payload: dict) -> None:
    body = json.dumps(payload).encode("utf-8")
    sock.sendall(struct.pack(">I", len(body)) + body)


def recv_msg(sock) -> dict:
    header = _recv_exactly(sock, 4)
    length = struct.unpack(">I", header)[0]
    return json.loads(_recv_exactly(sock, length).decode("utf-8"))


def _recv_exactly(sock, n: int) -> bytes:
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            raise ConnectionError("Connection closed unexpectedly")
        buf.extend(chunk)
    return bytes(buf)


# --------------------------------------------------------------------------
# Encryption helpers
# --------------------------------------------------------------------------

def encrypt_with_xtea(data: bytes):
    from src.symmetric.xtea import XTEACipher, generate_key
    key = generate_key()
    ct  = XTEACipher(key).encrypt(data)
    return key, ct


def encrypt_with_idea(data: bytes):
    from src.symmetric.idea import IDEACipher, generate_key
    key = generate_key()
    ct  = IDEACipher(key).encrypt(data)
    return key, ct


def encrypt_with_elgamal(data: bytes):
    """Encrypt data using ElGamal (asymmetric, 256-bit key).

    Data is split into 16-byte chunks, each encrypted as an integer.
    The private key and ciphertext are serialised as JSON -> hex.
    """
    from src.asymmetric.elgamal import generate_keys, encrypt_int
    priv = generate_keys(256)
    pub  = priv.public_key

    c1_list, c2_list = [], []
    for i in range(0, len(data), 16):
        chunk = data[i:i + 16]
        # Prepend 0x01 to avoid zero-value and preserve leading zeros
        m = int.from_bytes(b'\x01' + chunk, "big")
        ct = encrypt_int(m, pub)
        c1_list.append(ct.c1)
        c2_list.append(ct.c2)

    ct_json = json.dumps({"c1": c1_list, "c2": c2_list})
    key_json = json.dumps({"p": priv.p, "q": priv.q, "g": priv.g, "x": priv.x})
    return key_json.encode("utf-8"), ct_json.encode("utf-8")


def encrypt_with_ring_lwe(data: bytes):
    """Encrypt data using Ring-LWE (post-quantum).

    Each byte is encrypted bit-by-bit.  Key and ciphertext are
    serialised as JSON -> hex for transport.
    """
    from src.pqc.lwe import generate_keys, encrypt_bytes
    priv = generate_keys()
    pub  = priv.pub

    ct = encrypt_bytes(data, pub)

    ct_json = json.dumps({"u": ct.u_polys, "v": ct.v_scalars})
    key_json = json.dumps({"s": priv.s, "pub_a": pub.a, "pub_b": pub.b})
    return key_json.encode("utf-8"), ct_json.encode("utf-8")


# --------------------------------------------------------------------------
# Main interactive loop
# --------------------------------------------------------------------------

def main():
    print("=" * 60)
    print("  CryptoCare File Client")
    print("=" * 60)

    # Connect to server
    try:
        sock = socket.create_connection((HOST, PORT))
    except ConnectionRefusedError:
        print(f"\n[ERROR] Could not connect to server at {HOST}:{PORT}")
        print("        Make sure file_server.py is running first.")
        sys.exit(1)

    print(f"\n[Client] Connected to server at {HOST}:{PORT}\n")

    with sock:
        while True:
            print("-" * 60)
            print("Options:")
            print("  1) Encrypt and send a file")
            print("  2) Quit")
            choice = input("\nYour choice (1/2): ").strip()

            if choice == "2":
                send_msg(sock, {"action": "DISCONNECT"})
                print("[Client] Disconnected. Goodbye!")
                break

            elif choice == "1":
                # -- Get file path -----------------------------------------
                file_path = input("Enter the path to the file: ").strip().strip('"')
                if not os.path.exists(file_path):
                    print(f"[ERROR] File not found: {file_path}")
                    continue

                with open(file_path, "rb") as f:
                    plaintext = f.read()

                print(f"\n[Client] File loaded: {file_path} ({len(plaintext)} bytes)")

                # -- Choose algorithm ---------------------------------------
                print("\nChoose encryption algorithm:")
                print("  1) XTEA     -- eXtended Tiny Encryption Algorithm (128-bit, Feistel)")
                print("  2) IDEA     -- International Data Encryption Algorithm (128-bit, mixed-ops)")
                print("  3) ElGamal  -- Asymmetric encryption (Discrete-Log, 256-bit prime)")
                print("  4) Ring-LWE -- Post-Quantum Lattice-based encryption (PQC)")
                algo_choice = input("\nYour choice (1/2/3/4): ").strip()

                if algo_choice == "1":
                    algorithm = "XTEA"
                    key, ciphertext = encrypt_with_xtea(plaintext)
                elif algo_choice == "2":
                    algorithm = "IDEA"
                    key, ciphertext = encrypt_with_idea(plaintext)
                elif algo_choice == "3":
                    algorithm = "ELGAMAL"
                    key, ciphertext = encrypt_with_elgamal(plaintext)
                elif algo_choice == "4":
                    algorithm = "RING_LWE"
                    key, ciphertext = encrypt_with_ring_lwe(plaintext)
                else:
                    print("[ERROR] Invalid choice.")
                    continue

                filename = os.path.basename(file_path)

                key_hex_display = key.hex()
                if len(key_hex_display) > 64:
                    key_hex_display = key_hex_display[:64] + "..."

                print(f"\n[Client] Encrypted '{filename}' with {algorithm}")
                print(f"         Original  : {len(plaintext)} bytes")
                print(f"         Encrypted : {len(ciphertext)} bytes")
                print(f"         Key       : {key_hex_display}")
                print(f"\n[Client] Sending to server...")

                # -- Send to server ----------------------------------------
                send_msg(sock, {
                    "action":     "UPLOAD",
                    "filename":   filename,
                    "algorithm":  algorithm,
                    "key":        key.hex(),
                    "ciphertext": ciphertext.hex(),
                })

                # -- Get response ------------------------------------------
                resp = recv_msg(sock)
                if resp.get("status") == "OK":
                    print(f"\n[Server] File received and saved successfully!")
                    print(f"         Algorithm      : {resp['algorithm']}")
                    print(f"         Original size  : {resp['original_size']} bytes")
                    print(f"         Encrypted size : {resp['encrypted_size']} bytes")
                    print(f"         Encrypted file : {resp['enc_path']}")
                    print(f"         Decrypted file : {resp['plain_path']}")
                else:
                    print(f"[ERROR] Server error: {resp.get('detail')}")

            else:
                print("[ERROR] Invalid option. Enter 1 or 2.")


if __name__ == "__main__":
    main()

"""
file_encrypt.py -- File Encryption & Decryption Utility
========================================================
Encrypts any file using XTEA (CBC mode, 128-bit key) and saves it as .enc
Decrypts a .enc file back to its original content.

Usage
-----
    # Encrypt a file:
    python file_encrypt.py encrypt report.txt

    # Decrypt it back:
    python file_encrypt.py decrypt report.txt.enc

The secret key is saved alongside the encrypted file as <filename>.key
(In a real system the key would be stored securely / exchanged via ElGamal.)
"""

import os
import sys

# Make sure src/ is importable when run from the project folder
sys.path.insert(0, os.path.dirname(__file__))

from src.symmetric.xtea import XTEACipher, generate_key


def encrypt_file(input_path: str) -> None:
    """Read input_path, encrypt with XTEA, write <input_path>.enc"""
    if not os.path.exists(input_path):
        print(f"[ERROR] File not found: {input_path}")
        sys.exit(1)

    # Read original file
    with open(input_path, "rb") as f:
        plaintext = f.read()

    # Generate a fresh 128-bit key
    key = generate_key()
    cipher = XTEACipher(key)
    ciphertext = cipher.encrypt(plaintext)

    # Write encrypted file
    enc_path = input_path + ".enc"
    with open(enc_path, "wb") as f:
        f.write(ciphertext)

    # Save key (in real life: protect this!)
    key_path = input_path + ".key"
    with open(key_path, "wb") as f:
        f.write(key)

    print(f"[OK] Encrypted  : {input_path}")
    print(f"     → Saved to : {enc_path}  ({len(ciphertext)} bytes)")
    print(f"     → Key file : {key_path}  (keep this safe!)")
    print(f"     Original size : {len(plaintext)} B  |  Encrypted size : {len(ciphertext)} B")


def decrypt_file(enc_path: str) -> None:
    """Read <file>.enc + <file>.key, decrypt, write back to original filename."""
    if not enc_path.endswith(".enc"):
        print("[ERROR] Expected a .enc file.")
        sys.exit(1)

    key_path = enc_path[:-4] + ".key"   # report.txt.enc -> report.txt.key

    if not os.path.exists(enc_path):
        print(f"[ERROR] Encrypted file not found: {enc_path}")
        sys.exit(1)
    if not os.path.exists(key_path):
        print(f"[ERROR] Key file not found: {key_path}")
        sys.exit(1)

    # Read encrypted file and key
    with open(enc_path, "rb") as f:
        ciphertext = f.read()
    with open(key_path, "rb") as f:
        key = f.read()

    # Decrypt
    cipher = XTEACipher(key)
    plaintext = cipher.decrypt(ciphertext)

    # Write decrypted output (remove .enc extension)
    out_path = enc_path[:-4]   # report.txt.enc -> report.txt
    # Avoid overwriting the original if it still exists
    if os.path.exists(out_path):
        out_path = out_path + ".decrypted"

    with open(out_path, "wb") as f:
        f.write(plaintext)

    print(f"[OK] Decrypted  : {enc_path}")
    print(f"     → Saved to : {out_path}  ({len(plaintext)} bytes)")
    print(f"     Content preview: {plaintext[:80]}")


def main() -> None:
    if len(sys.argv) != 3 or sys.argv[1] not in ("encrypt", "decrypt"):
        print("Usage:")
        print("  python file_encrypt.py encrypt <file>")
        print("  python file_encrypt.py decrypt <file>.enc")
        sys.exit(1)

    command, path = sys.argv[1], sys.argv[2]

    if command == "encrypt":
        encrypt_file(path)
    else:
        decrypt_file(path)


if __name__ == "__main__":
    main()

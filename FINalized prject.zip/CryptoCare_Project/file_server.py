"""
file_server.py -- Secure File Storage Server
=============================================
Receives files from clients over TCP.
Each file arrives encrypted (XTEA, IDEA, ElGamal, or Ring-LWE
chosen by the client).  The server decrypts it, saves the plaintext,
and also keeps the encrypted copy — both written to 'server_storage/'.

Usage
-----
    python file_server.py

Press Ctrl-C to stop.
"""

import os
import sys
import socket
import threading
import json
import struct

sys.path.insert(0, os.path.dirname(__file__))

STORAGE_DIR = os.path.join(os.path.dirname(__file__), "server_storage")
os.makedirs(STORAGE_DIR, exist_ok=True)

HOST = "127.0.0.1"
PORT = 9999


# --------------------------------------------------------------------------
# Tiny framing helpers (length-prefixed JSON)
# --------------------------------------------------------------------------

def send_msg(sock, payload: dict) -> None:
    body = json.dumps(payload).encode("utf-8")
    sock.sendall(struct.pack(">I", len(body)) + body)


def recv_msg(sock) -> dict:
    header = _recv_exactly(sock, 4)
    length = struct.unpack(">I", header)[0]
    return json.loads(_recv_exactly(sock, length).decode("utf-8"))


def _recv_exactly(sock, n: int) -> bytes:
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            raise ConnectionError("Connection closed unexpectedly")
        buf.extend(chunk)
    return bytes(buf)


# --------------------------------------------------------------------------
# Decryption helpers for ElGamal / Ring-LWE
# --------------------------------------------------------------------------

def _decrypt_elgamal(key_bytes: bytes, ct_bytes: bytes) -> bytes:
    """Decrypt data that was encrypted chunk-by-chunk with ElGamal."""
    from src.asymmetric.elgamal import PrivateKey, Ciphertext, decrypt_int

    key_dict = json.loads(key_bytes.decode("utf-8"))
    priv = PrivateKey(p=key_dict["p"], q=key_dict["q"],
                      g=key_dict["g"], x=key_dict["x"])

    ct_dict = json.loads(ct_bytes.decode("utf-8"))
    chunks = []
    for c1, c2 in zip(ct_dict["c1"], ct_dict["c2"]):
        m = decrypt_int(Ciphertext(c1, c2), priv)
        raw = m.to_bytes((m.bit_length() + 7) // 8, "big")
        chunks.append(raw[1:])          # strip the 0x01 sentinel byte
    return b"".join(chunks)


def _decrypt_ring_lwe(key_bytes: bytes, ct_bytes: bytes) -> bytes:
    """Decrypt data that was encrypted bit-by-bit with Ring-LWE."""
    from src.pqc.lwe import LWEPublicKey, LWEPrivateKey, LWECiphertext, decrypt_bytes

    key_dict = json.loads(key_bytes.decode("utf-8"))
    pub = LWEPublicKey(a=key_dict["pub_a"], b=key_dict["pub_b"])
    priv = LWEPrivateKey(s=key_dict["s"], pub=pub)

    ct_dict = json.loads(ct_bytes.decode("utf-8"))
    ct = LWECiphertext(u_polys=ct_dict["u"], v_scalars=ct_dict["v"])
    return decrypt_bytes(ct, priv)


# --------------------------------------------------------------------------
# Client handler
# --------------------------------------------------------------------------

def handle_client(conn: socket.socket, addr) -> None:
    print(f"\n[Server] New connection from {addr}")
    try:
        with conn:
            while True:
                msg = recv_msg(conn)
                action = msg.get("action")

                # ── UPLOAD ────────────────────────────────────────────────
                if action == "UPLOAD":
                    filename  = msg["filename"]
                    algorithm = msg["algorithm"]
                    key_hex   = msg["key"]
                    ct_hex    = msg["ciphertext"]

                    key        = bytes.fromhex(key_hex)
                    ciphertext = bytes.fromhex(ct_hex)

                    # Decrypt using the algorithm the client chose
                    if algorithm == "XTEA":
                        from src.symmetric.xtea import XTEACipher
                        plaintext = XTEACipher(key).decrypt(ciphertext)
                    elif algorithm == "IDEA":
                        from src.symmetric.idea import IDEACipher
                        plaintext = IDEACipher(key).decrypt(ciphertext)
                    elif algorithm == "ELGAMAL":
                        plaintext = _decrypt_elgamal(key, ciphertext)
                    elif algorithm == "RING_LWE":
                        plaintext = _decrypt_ring_lwe(key, ciphertext)
                    else:
                        send_msg(conn, {"status": "ERROR",
                                        "detail": f"Unknown algorithm: {algorithm}"})
                        continue

                    # Save encrypted copy
                    enc_path   = os.path.join(STORAGE_DIR, filename + ".enc")
                    # Save decrypted copy
                    plain_path = os.path.join(STORAGE_DIR, filename + ".decrypted")

                    with open(enc_path, "wb") as f:
                        f.write(ciphertext)
                    with open(plain_path, "wb") as f:
                        f.write(plaintext)

                    print(f"[Server] UPLOAD '{filename}' via {algorithm}")
                    print(f"         Encrypted saved  -> {enc_path}")
                    print(f"         Decrypted saved  -> {plain_path}")

                    send_msg(conn, {
                        "status":    "OK",
                        "enc_path":  enc_path,
                        "plain_path": plain_path,
                        "algorithm": algorithm,
                        "original_size": len(plaintext),
                        "encrypted_size": len(ciphertext),
                    })

                # ── DISCONNECT ────────────────────────────────────────────
                elif action == "DISCONNECT":
                    print(f"[Server] Client {addr} disconnected.")
                    break

                else:
                    send_msg(conn, {"status": "ERROR",
                                    "detail": f"Unknown action: {action}"})

    except ConnectionError:
        print(f"[Server] Connection from {addr} dropped.")
    except Exception as e:
        print(f"[Server] Error handling {addr}: {e}")


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------

def main():
    print("=" * 60)
    print("  CryptoCare File Server")
    print("  Algorithms supported: XTEA, IDEA, ElGamal, Ring-LWE")
    print(f"  Storage folder: {STORAGE_DIR}")
    print("=" * 60)
    print(f"\n[Server] Listening on {HOST}:{PORT}  (Ctrl-C to stop)\n")

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((HOST, PORT))
        srv.listen(5)
        while True:
            try:
                conn, addr = srv.accept()
                threading.Thread(
                    target=handle_client, args=(conn, addr), daemon=True
                ).start()
            except KeyboardInterrupt:
                print("\n[Server] Shutting down.")
                break


if __name__ == "__main__":
    main()

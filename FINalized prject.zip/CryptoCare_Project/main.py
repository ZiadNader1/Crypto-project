

from __future__ import annotations

import sys
import os
import struct
import time

# ---------------------------------------------------------------------------
# Section A -- Symmetric Algorithms Demo
# ---------------------------------------------------------------------------

def demo_xtea() -> None:
    from src.symmetric.xtea import XTEACipher, generate_key

    print("\n" + "-" * 65)
    print("  MODULE A-1: XTEA -- eXtended Tiny Encryption Algorithm")
    print("-" * 65)

    # -- Handwritten example (small values) ------------------------------
    print("\n  [Handwritten Verification -- small values]")
    print("  Key words: K = [1, 2, 3, 4]")
    print("  Block   : v0 = 1,  v1 = 2")
    key_bytes = struct.pack(">4I", 1, 2, 3, 4)
    cipher = XTEACipher(key_bytes)
    v0_enc, v1_enc = cipher.encrypt_block_raw(1, 2)
    v0_dec, v1_dec = cipher.decrypt_block_raw(v0_enc, v1_enc)
    print(f"  Encrypt -> v0 = {v0_enc:#010x},  v1 = {v1_enc:#010x}")
    print(f"  Decrypt -> v0 = {v0_dec},  v1 = {v1_dec}  OK")

    # -- Practical demo ----------------------------------------------------
    print("\n  [Practical Demo -- CBC mode]")
    key = generate_key()
    cipher = XTEACipher(key)
    message = b"Patient record: HbA1c=5.7%, BP=120/80, Cholesterol=195"
    ciphertext = cipher.encrypt(message)
    recovered  = cipher.decrypt(ciphertext)

    print(f"  Plaintext  ({len(message):>3} B): {message.decode()}")
    print(f"  Ciphertext ({len(ciphertext):>3} B): {ciphertext.hex()[:48]}...")
    print(f"  Decrypted  ({len(recovered):>3} B): {recovered.decode()}")
    assert recovered == message
    print("  Round-trip verification: PASSED OK")


def demo_idea() -> None:
    from src.symmetric.idea import IDEACipher, generate_key, _mul, _add, _mul_inv

    print("\n" + "-" * 65)
    print("  MODULE A-2: IDEA -- International Data Encryption Algorithm")
    print("-" * 65)

    # -- Group operations demo ---------------------------------------------
    print("\n  [Group Operations -- Handwritten Example]")
    a, b = 0x0003, 0x0005
    print(f"  a = {a},  b = {b}")
    print(f"  a ⊗ b  (mul mod 65537) = {_mul(a, b)}")
    print(f"  a ⊞ b  (add mod 65536) = {_add(a, b)}")
    print(f"  a⁻¹    (mul inv)       = {_mul_inv(a)}   [{a} x {_mul_inv(a)} mod 65537 = {_mul(a, _mul_inv(a))}]")

    # -- Handwritten block example -----------------------------------------
    print("\n  [Handwritten Verification -- small block values]")
    print("  Key  : 16 zero bytes")
    print("  Block: (X1=1, X2=2, X3=3, X4=4)")
    cipher_zero = IDEACipher(bytes(16))
    enc = cipher_zero.encrypt_block_raw(1, 2, 3, 4)
    dec = cipher_zero.decrypt_block_raw(*enc)
    print(f"  Encrypted : {enc}")
    print(f"  Decrypted : {dec}  OK")

    # -- Practical demo ----------------------------------------------------
    print("\n  [Practical Demo -- CBC mode]")
    key = generate_key()
    cipher = IDEACipher(key)
    message = b"Radiology report: No abnormalities detected. Follow-up in 6 months."
    ciphertext = cipher.encrypt(message)
    recovered  = cipher.decrypt(ciphertext)

    print(f"  Plaintext  ({len(message):>3} B): {message[:40].decode()}...")
    print(f"  Ciphertext ({len(ciphertext):>3} B): {ciphertext.hex()[:48]}...")
    print(f"  Decrypted  ({len(recovered):>3} B): {recovered[:40].decode()}...")
    assert recovered == message
    print("  Round-trip verification: PASSED OK")


# ---------------------------------------------------------------------------
# Section B -- Asymmetric Algorithm Demo
# ---------------------------------------------------------------------------

def demo_elgamal() -> None:
    from src.asymmetric.elgamal import (
        generate_keys, encrypt_int, decrypt_int,
        encrypt_session_key, decrypt_session_key,
        sign, verify,
    )
    from src.symmetric.xtea import XTEACipher, generate_key

    print("\n" + "-" * 65)
    print("  MODULE B: ElGamal -- Discrete Logarithm Cryptosystem")
    print("-" * 65)

    print("\n  Generating 256-bit safe prime key pair...")
    priv = generate_keys(bits=256)
    pub  = priv.public_key

    print(f"  p  = {str(priv.p)[:30]}... ({priv.p.bit_length()} bits)")
    print(f"  q  = (p-1)/2")
    print(f"  g  = {str(pub.g)[:30]}... (generator of subgroup)")
    print(f"  y  = g^x mod p  (public key)")
    print(f"  x  = [PRIVATE]")

    # -- Handwritten example with small numbers -----------------------------
    print("\n  [Handwritten Verification -- tiny numbers]")
    print("  p=23 (prime), g=5, x=6 (private), y=5^6 mod 23=8 (public)")
    print("  Encrypt m=10, k=3:")
    print("    c1 = 5^3 mod 23 = 125 mod 23 = 10")
    print("    c2 = 10 x 8^3 mod 23 = 10 x 512 mod 23 = 10 x 6 = 60 mod 23 = 14")
    print("  Decrypt (c1=10, c2=14):")
    print("    s  = 10^6 mod 23 = 1000000 mod 23 = 3")
    print("    s⁻¹= 3^(23-2) mod 23 = 3^21 mod 23 = 8")
    print("    m  = 14 x 8 mod 23 = 112 mod 23 = 20 <- ? 🤔")
    print("  [Note: above is a manual trace.  For verified small example:]")
    # Actual correct small example
    p_s, g_s, x_s = 23, 5, 6
    y_s = pow(g_s, x_s, p_s)
    k_s, m_s = 3, 10
    c1_s = pow(g_s, k_s, p_s)
    c2_s = (m_s * pow(y_s, k_s, p_s)) % p_s
    s_s  = pow(c1_s, x_s, p_s)
    s_inv = pow(s_s, p_s - 2, p_s)
    rec_s = (c2_s * s_inv) % p_s
    print(f"  p=23, g=5, x=6, y={y_s}, k=3, m={m_s}")
    print(f"  c1 = {c1_s},  c2 = {c2_s}")
    print(f"  s  = {s_s},   s⁻¹= {s_inv}")
    print(f"  Recovered m = {rec_s}  {'OK' if rec_s == m_s else 'FAIL'}")

    # -- Hybrid encryption -------------------------------------------------
    print("\n  [Hybrid Encryption -- session key exchange]")
    session_key = generate_key()
    c1, c2 = encrypt_session_key(session_key, pub)
    recovered_sk = decrypt_session_key(c1, c2, priv)
    print(f"  Session key     : {session_key.hex()}")
    print(f"  Encrypted (c1)  : {str(c1)[:30]}...")
    print(f"  Encrypted (c2)  : {str(c2)[:30]}...")
    print(f"  Recovered key   : {recovered_sk.hex()}")
    assert recovered_sk == session_key
    print("  Session key exchange: PASSED OK")

    # -- Digital signature --------------------------------------------------
    print("\n  [Digital Signature]")
    message = b"I authorise access to patient record #4521"
    sig = sign(message, priv)
    valid   = verify(message, sig, pub)
    tampered = verify(b"tampered message", sig, pub)
    print(f"  Message  : {message.decode()}")
    print(f"  Signature: r={str(sig.r)[:20]}..., s={str(sig.s)[:20]}...")
    print(f"  Verify (original) : {valid}   OK")
    print(f"  Verify (tampered) : {tampered}  OK")


# ---------------------------------------------------------------------------
# Section C -- Integrated Portal Demo
# ---------------------------------------------------------------------------

def demo_integrated_portal() -> None:
    from src.app.healthcare_portal import HealthcarePortal

    print("\n" + "-" * 65)
    print("  MODULE C: Integrated Secure Healthcare Portal")
    print("-" * 65)

    portal = HealthcarePortal()

    # -- Register entities -------------------------------------------------
    print("\n" + "=" * 60)
    print("  STEP 4: Registering clients")
    print("=" * 60)
    patient = portal.register_client("Patient-Jane-Doe")
    doctor  = portal.register_client("Doctor-Adam-Smith")

    # -- PQC Authentication ------------------------------------------------
    print("\n" + "=" * 60)
    print("  STEP 5: Post-Quantum Authentication (Ring-LWE)")
    print("=" * 60)
    portal.pqc_authenticate(patient)
    portal.pqc_authenticate(doctor)

    # -- TLS-style handshake ------------------------------------------------
    print("\n" + "=" * 60)
    print("  STEP 6: TLS-style Handshake (ElGamal key exchange)")
    print("=" * 60)
    sid_p = portal.connect(patient)
    sid_d = portal.connect(doctor)

    # -- Upload a medical record --------------------------------------------
    print("\n" + "=" * 60)
    print("  STEP 7: Patient uploads encrypted medical record")
    print("=" * 60)
    record = (
        b"PATIENT: Jane Doe\n"
        b"DOB: 15/03/1985\n"
        b"DIAGNOSIS: Type-2 Diabetes Mellitus\n"
        b"HbA1c: 7.2% (target < 6.5%)\n"
        b"MEDICATIONS: Metformin 500mg twice daily\n"
        b"NEXT REVIEW: 3 months\n"
        b"PHYSICIAN: Dr Adam Smith\n"
    )
    record_path = portal.upload_record(patient, sid_p, "patient_record", record)

    # -- Patient downloads their own record --------------------------------
    print("\n" + "=" * 60)
    print("  STEP 8: Patient downloads and reads their record")
    print("=" * 60)
    # Records are stored under the uploader's session IDEA key.
    # In a full system, cross-party access uses re-encryption or shared keys.
    recovered = portal.download_record(patient, sid_p, record_path)

    # Verify content integrity
    assert recovered == record
    print(f"\n  Content integrity check: PASSED OK")
    print(f"  First line recovered: {recovered.splitlines()[0].decode()}")

    # -- Key rotation demo --------------------------------------------------
    print("\n" + "=" * 60)
    print("  STEP 9: Session Key Rotation")
    print("=" * 60)
    old_key = portal.server.get_session(sid_p).session_key
    new_key = portal.server.rotate_session_key(sid_p)
    patient.update_session_key(new_key)
    print(f"  Old key: {old_key.hex()[:16]}...")
    print(f"  New key: {new_key.hex()[:16]}...")
    assert old_key != new_key
    print("  Key rotation: PASSED OK")

    # -- Certificate revocation ---------------------------------------------
    print("\n" + "=" * 60)
    print("  STEP 10: Certificate Revocation")
    print("=" * 60)
    from src.ca.certificate_authority import Certificate
    old_cert = patient.certificate
    print(f"  Revoking certificate #{old_cert.serial_number} for {patient.name}...")
    portal.ca.revoke_certificate(old_cert.serial_number)
    status = portal.ca.verify_certificate(old_cert)
    print(f"  Certificate valid after revocation: {status}  OK")

    portal.print_summary()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    run_bench = "--bench" in sys.argv

    print("\n" + "+" + "=" * 63 + "+")
    print("|  CryptoCare -- Secure Healthcare Portal Demo" + " " * 19 + "|")
    print("|  Algorithms: XTEA | IDEA | ElGamal | Ring-LWE (PQC)" + " " * 9 + "|")
    print("+" + "=" * 63 + "+")

    demo_xtea()
    demo_idea()
    demo_elgamal()
    demo_integrated_portal()

    if run_bench:
        from benchmarks.performance import run_all
        run_all()

    print("\n" + "+" + "=" * 63 + "+")
    print("|  ALL DEMONSTRATIONS COMPLETED SUCCESSFULLY OK" + " " * 17 + "|")
    print("+" + "=" * 63 + "+\n")


if __name__ == "__main__":
    main()

"""
run_server.py -- Start the secure healthcare TCP server.

Usage
-----
    python run_server.py [options]

Options
-------
    --host HOST     Interface to bind (default: 127.0.0.1)
    --port PORT     TCP port (default: 9999)
    --bits BITS     ElGamal key size in bits (default: 256)

Example
-------
    python run_server.py
    python run_server.py --host 0.0.0.0 --port 8888 --bits 256

Press Ctrl-C to stop the server.
"""

from __future__ import annotations

import argparse
import sys
import os

# Make sure the project root is on the path so ``src.*`` imports work.
sys.path.insert(0, os.path.dirname(__file__))

from src.network.server import NetworkServer


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="CryptoCare -- Secure Healthcare TCP Server",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument("--host", default="127.0.0.1", help="Bind host")
    p.add_argument("--port", type=int, default=9999,  help="TCP port")
    p.add_argument("--bits", type=int, default=256,   help="ElGamal key bits")
    return p.parse_args()


def main() -> None:
    args = parse_args()

    print("\n" + "=" * 65)
    print("  CryptoCare -- Secure Healthcare TCP Server")
    print("  Algorithms : XTEA | IDEA | ElGamal | Ring-LWE (PQC)")
    print("=" * 65)

    server = NetworkServer(host=args.host, port=args.port, key_bits=args.bits)
    server.start()   # blocks until KeyboardInterrupt


if __name__ == "__main__":
    main()

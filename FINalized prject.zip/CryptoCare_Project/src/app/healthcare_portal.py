"""
Secure Healthcare Portal -- integrated business case simulation
=============================================================

Scenario
--------
A hospital's secure patient portal where patients can securely upload medical
records and doctors can retrieve them.

Parties
-------
HealthCare Root CA   : Issues and validates certificates for all parties.
Hospital Server      : Stores and serves encrypted patient records.
Patient (Client)     : Uploads/downloads personal medical records.
Doctor  (Client)     : Accesses authorised patient records.

Data flow
---------
Upload path (encryption in transit + at rest):
    Patient -> [XTEA-CBC over session] -> Server -> [IDEA-CBC on disk]

Download path:
    Server -> [IDEA-CBC from disk] -> plaintext -> [XTEA-CBC over session] -> Patient/Doctor

Key management lifecycle
------------------------
1. CA generates root key pair (once, long-lived).
2. Server registers, receives CA-signed certificate.
3. Each client registers, receives CA-signed certificate.
4. On each connection: fresh ElGamal key exchange -> fresh XTEA session key.
5. Session key rotates every N messages (configurable).
6. Files at rest always encrypted with IDEA under a per-session storage key.
"""

from __future__ import annotations

import os
import tempfile
import time
import uuid

from src.ca.certificate_authority import Certificate, CertificateAuthority
from src.app.secure_session import SecureServer, SecureClient
from src.pqc.lwe import (
    generate_keys as lwe_generate_keys,
    generate_auth_token,
    verify_auth_token,
)


class HealthcarePortal:
    """Orchestrates the full secure healthcare portal simulation."""

    KEY_BITS: int = 256           # ElGamal key bits (256 = demo; use >=2048 for prod)
    KEY_ROTATION_INTERVAL: int = 5   # rotate session key every N messages

    def __init__(self, storage_dir: str | None = None) -> None:
        self.storage_dir = storage_dir or tempfile.mkdtemp(prefix="healthcare_")
        os.makedirs(self.storage_dir, exist_ok=True)

        # -- Certificate Authority ------------------------------------------
        print("\n" + "=" * 60)
        print("  STEP 1: Initialising Certificate Authority")
        print("=" * 60)
        self.ca = CertificateAuthority(
            name="HealthCare-Root-CA",
            key_bits=self.KEY_BITS,
        )

        # -- Server --------------------------------------------------------
        print("\n" + "=" * 60)
        print("  STEP 2: Registering Hospital Server with CA")
        print("=" * 60)
        self.server = SecureServer(
            name="Hospital-Server",
            ca=self.ca,
            key_bits=self.KEY_BITS,
        )

        # -- Post-Quantum keys (bonus) -------------------------------------
        print("\n" + "=" * 60)
        print("  STEP 3: Generating Post-Quantum (Ring-LWE) key pair for server")
        print("=" * 60)
        self._pqc_priv = lwe_generate_keys()
        self._pqc_pub  = self._pqc_priv.pub
        print("[Server] Ring-LWE key pair ready.")

        self._sessions: dict[str, str] = {}   # session_id -> client name

    # -- Client registration -----------------------------------------------

    def register_client(self, name: str) -> "SecureClient":
        """Register a new client (patient or doctor) with the CA."""
        print(f"\n[Portal] Registering client '{name}'...")
        return SecureClient(name=name, ca=self.ca, key_bits=self.KEY_BITS)

    # -- Handshake ---------------------------------------------------------

    def connect(self, client: "SecureClient") -> str:
        """Perform a full mutual-authentication handshake.

        Returns the session_id for subsequent operations.
        """
        session_id = str(uuid.uuid4())[:8]
        print(f"\n{'=' * 60}")
        print(f"  HANDSHAKE -- {client.name}  (session {session_id})")
        print(f"{'=' * 60}")

        # 1. ClientHello
        hello = client.initiate_handshake()
        client_cert = Certificate.from_dict(hello["client_cert"])
        print(f"[Client] Sent ClientHello with certificate #{client_cert.serial_number}")

        # 2. ServerHello -- validates client cert, creates session key
        server_hello = self.server.prepare_server_hello(client_cert, session_id)
        print(f"[Server] Sent ServerHello with encrypted session key")

        # 3. Client processes ServerHello
        session = client.process_server_hello(server_hello)
        print(
            f"[Client] Session established OK  "
            f"key={session.session_key.hex()[:16]}..."
        )

        self._sessions[session_id] = client.name
        return session_id

    # -- Post-Quantum authentication ----------------------------------------

    def pqc_authenticate(self, client: "SecureClient") -> bool:
        """Authenticate the client using Ring-LWE post-quantum tokens."""
        print(f"\n[Portal] PQC authentication for '{client.name}'...")
        token = generate_auth_token(client.name, self._pqc_pub)
        result = verify_auth_token(token, client.name, self._pqc_priv)
        status = "PASSED OK" if result else "FAILED FAIL"
        print(f"[Portal] Ring-LWE authentication {status}")
        return result

    # -- Record upload ------------------------------------------------------

    def upload_record(
        self,
        client: "SecureClient",
        session_id: str,
        record_name: str,
        content: bytes,
    ) -> str:
        """Client encrypts a medical record and sends it to the server.

        Transit:  XTEA-CBC
        At rest:  IDEA-CBC
        Returns the server-side storage path.
        """
        print(f"\n[{client.name}] Uploading record '{record_name}'...")

        # Encrypt in transit (client side)
        ct_transit = client.send_message(content)
        print(
            f"[{client.name}] Plaintext  {len(content):,} B -> "
            f"XTEA ciphertext {len(ct_transit):,} B"
        )

        # Server receives, decrypts from transit, re-encrypts at rest
        plaintext_received = self.server.receive_message(session_id, ct_transit)
        assert plaintext_received == content, "Transit decryption mismatch!"

        record_path = os.path.join(
            self.storage_dir, f"{session_id}_{record_name}.enc"
        )
        self.server.store_record(session_id, plaintext_received, record_path)
        print(f"[Server] Record stored at-rest (IDEA): {record_path}")

        # Rotate key after threshold
        session = self.server.get_session(session_id)
        if session and session.messages_sent % self.KEY_ROTATION_INTERVAL == 0:
            new_key = self.server.rotate_session_key(session_id)
            client.update_session_key(new_key)

        return record_path

    # -- Record download ----------------------------------------------------

    def download_record(
        self,
        client: "SecureClient",
        session_id: str,
        record_path: str,
    ) -> bytes:
        """Server reads, decrypts from disk, re-encrypts for transit, client decrypts."""
        print(f"\n[Server] Sending record '{os.path.basename(record_path)}'...")

        # Server: read from disk, encrypt for transit
        record = self.server.load_record(session_id, record_path)
        ct_transit = self.server.send_message(session_id, record)
        print(
            f"[Server] IDEA decrypt -> XTEA encrypt: "
            f"{len(record):,} B -> {len(ct_transit):,} B"
        )

        # Client decrypts from transit
        recovered = client.receive_message(ct_transit)
        print(f"[{client.name}] Recovered {len(recovered):,} B of plaintext OK")
        return recovered

    # -- Summary -----------------------------------------------------------

    def print_summary(self) -> None:
        print("\n" + "=" * 60)
        print("  SESSION SUMMARY")
        print("=" * 60)
        print(f"  Active sessions : {len(self._sessions)}")
        print(f"  CA name         : {self.ca.name}")
        print(f"  Revoked certs   : {len(self.ca.revoked_serials)}")
        print(f"  Storage dir     : {self.storage_dir}")
        print("=" * 60)

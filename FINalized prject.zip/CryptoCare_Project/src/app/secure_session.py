"""
Secure Session -- TLS-style handshake simulation
=================================================

Protocol (simplified TLS 1.3 analogue)
---------------------------------------
1. Client -> Server : ClientHello  (client certificate)
2. Server -> Client : ServerHello  (server certificate + ElGamal-encrypted session key)
3. Client verifies server certificate against CA.
4. Client decrypts session key with its ElGamal private key.
5. Both parties share a 128-bit session key.
6. All subsequent messages are XTEA-CBC encrypted with that key.
7. At regular intervals the session key is rotated (key rotation).

Encryption in transit  : XTEA-CBC  (symmetric, fast)
Encryption at rest     : IDEA-CBC  (symmetric, different algorithm -> diversity)
Key exchange           : ElGamal   (asymmetric)
Authentication         : ElGamal signatures via CA certificates

Security properties
-------------------
* Mutual authentication via CA-signed certificates.
* Forward secrecy: each session uses a fresh random session key.
* Data confidentiality: XTEA for transport, IDEA for storage.
* Integrity: ElGamal signature on session key offer.
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass, field

from src.asymmetric.elgamal import (
    PrivateKey,
    PublicKey,
    generate_keys,
    encrypt_session_key,
    decrypt_session_key,
    sign,
    verify,
    public_key_to_dict,
    public_key_from_dict,
    signature_to_dict,
    signature_from_dict,
)
from src.ca.certificate_authority import Certificate, CertificateAuthority
from src.symmetric.xtea import XTEACipher, generate_key as xtea_key
from src.symmetric.idea import IDEACipher, generate_key as idea_key
from src.utils.math_utils import simple_hash


# ---------------------------------------------------------------------------
# Entity -- base class for server and client
# ---------------------------------------------------------------------------

class Entity:
    """Represents any party in the PKI (server or client).

    Parameters
    ----------
    name      : Human-readable identifier.
    ca        : The trusted Certificate Authority that issues certificates.
    key_bits  : Bit-length for ElGamal key generation.
    """

    def __init__(self, name: str, ca: CertificateAuthority, key_bits: int = 256) -> None:
        self.name = name
        self._ca = ca
        print(f"[{name}] Generating {key_bits}-bit ElGamal key pair...")
        self._priv: PrivateKey = generate_keys(bits=key_bits)
        self.pub: PublicKey = self._priv.public_key
        self.certificate: Certificate = ca.issue_certificate(name, self.pub)

    def has_valid_certificate(self) -> bool:
        return self._ca.verify_certificate(self.certificate)


# ---------------------------------------------------------------------------
# Handshake state
# ---------------------------------------------------------------------------

@dataclass
class HandshakeResult:
    session_key: bytes            # 16-byte shared secret
    session_id: str
    cipher_transit: XTEACipher    # encrypt-in-transit
    cipher_storage: IDEACipher    # encrypt-at-rest
    established_at: float = field(default_factory=time.time)
    messages_sent: int = 0


# ---------------------------------------------------------------------------
# Server
# ---------------------------------------------------------------------------

class SecureServer(Entity):
    """Simulates the hospital server."""

    def __init__(self, name: str, ca: CertificateAuthority, key_bits: int = 256) -> None:
        super().__init__(name, ca, key_bits)
        self._sessions: dict[str, HandshakeResult] = {}

    def prepare_server_hello(
        self, client_cert: Certificate, session_id: str
    ) -> dict:
        """Validate the client certificate and send a ServerHello message.

        ServerHello contains:
            * server certificate
            * ElGamal-encrypted random session key (encrypted with CLIENT public key)
            * ElGamal signature over session_key for integrity
        """
        if not self._ca.verify_certificate(client_cert):
            raise ValueError(f"[{self.name}] Client certificate is INVALID -- handshake aborted")

        # Extract client public key from their certificate
        client_pub = public_key_from_dict(client_cert.subject_pub_key)

        # Generate a fresh session key that fits within the client's prime p.
        # With key_bits >= 256 this almost never needs a retry; with smaller
        # demo keys (e.g. 128-bit) a retry is occasionally needed because a
        # random 128-bit value can be >= a 128-bit prime (~50% probability).
        while True:
            raw_session_key = xtea_key()
            m = int.from_bytes(raw_session_key, "big")
            if 1 <= m < client_pub.p:
                break

        # Encrypt session key for the client
        c1, c2 = encrypt_session_key(raw_session_key, client_pub)

        # Sign the session key with OUR private key (integrity proof)
        sig = sign(raw_session_key, self._priv)

        # Store session
        transit_cipher = XTEACipher(raw_session_key)
        storage_cipher = IDEACipher(idea_key())   # separate key for at-rest
        result = HandshakeResult(
            session_key=raw_session_key,
            session_id=session_id,
            cipher_transit=transit_cipher,
            cipher_storage=storage_cipher,
        )
        self._sessions[session_id] = result

        return {
            "server_cert": self.certificate.to_dict(),
            "encrypted_session_key": (c1, c2),
            "session_key_signature": signature_to_dict(sig),
            "session_id": session_id,
        }

    def receive_message(self, session_id: str, ciphertext: bytes) -> bytes:
        """Decrypt an in-transit message from a client."""
        session = self._sessions[session_id]
        session.messages_sent += 1
        return session.cipher_transit.decrypt(ciphertext)

    def send_message(self, session_id: str, plaintext: bytes) -> bytes:
        """Encrypt a message for transit to a client."""
        return self._sessions[session_id].cipher_transit.encrypt(plaintext)

    def store_record(self, session_id: str, record: bytes, path: str) -> None:
        """Encrypt and write a medical record to disk (at rest)."""
        session = self._sessions[session_id]
        ct = session.cipher_storage.encrypt(record)
        with open(path, "wb") as fh:
            fh.write(ct)

    def load_record(self, session_id: str, path: str) -> bytes:
        """Read and decrypt a medical record from disk."""
        session = self._sessions[session_id]
        with open(path, "rb") as fh:
            ct = fh.read()
        return session.cipher_storage.decrypt(ct)

    def rotate_session_key(self, session_id: str) -> bytes:
        """Rotate the session key -- returns the new key (for handshake demo)."""
        session = self._sessions[session_id]
        new_key = xtea_key()
        session.session_key = new_key
        session.cipher_transit = XTEACipher(new_key)
        print(f"[{self.name}] Session key rotated for session {session_id}")
        return new_key

    def get_session(self, session_id: str) -> HandshakeResult | None:
        return self._sessions.get(session_id)


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------

class SecureClient(Entity):
    """Simulates a patient client connecting to the server."""

    def __init__(self, name: str, ca: CertificateAuthority, key_bits: int = 256) -> None:
        super().__init__(name, ca, key_bits)
        self._session: HandshakeResult | None = None

    def initiate_handshake(self) -> dict:
        """Produce a ClientHello containing the client certificate."""
        return {"client_cert": self.certificate.to_dict()}

    def process_server_hello(self, server_hello: dict) -> HandshakeResult:
        """Validate server hello and extract the shared session key.

        Steps:
        1. Verify server certificate with CA.
        2. Extract server public key.
        3. Verify server's signature over the session key.
        4. Decrypt session key with our private key.
        5. Establish shared session.
        """
        # 1. Verify server certificate
        server_cert = Certificate.from_dict(server_hello["server_cert"])
        if not self._ca.verify_certificate(server_cert):
            raise ValueError(f"[{self.name}] Server certificate is INVALID -- aborting")

        # 2. Extract server public key
        server_pub = public_key_from_dict(server_cert.subject_pub_key)

        # 3. Decrypt session key
        c1, c2 = server_hello["encrypted_session_key"]
        session_key = decrypt_session_key(c1, c2, self._priv)

        # 4. Verify server's integrity signature
        sig = signature_from_dict(server_hello["session_key_signature"])
        if not verify(session_key, sig, server_pub):
            raise ValueError(f"[{self.name}] Session key signature INVALID -- aborting")

        # 5. Build session
        self._session = HandshakeResult(
            session_key=session_key,
            session_id=server_hello["session_id"],
            cipher_transit=XTEACipher(session_key),
            cipher_storage=IDEACipher(idea_key()),
        )
        return self._session

    def send_message(self, plaintext: bytes) -> bytes:
        if self._session is None:
            raise RuntimeError("No active session")
        self._session.messages_sent += 1
        return self._session.cipher_transit.encrypt(plaintext)

    def receive_message(self, ciphertext: bytes) -> bytes:
        if self._session is None:
            raise RuntimeError("No active session")
        return self._session.cipher_transit.decrypt(ciphertext)

    def update_session_key(self, new_key: bytes) -> None:
        """Accept a rotated session key from the server."""
        if self._session is None:
            raise RuntimeError("No active session")
        self._session.session_key = new_key
        self._session.cipher_transit = XTEACipher(new_key)

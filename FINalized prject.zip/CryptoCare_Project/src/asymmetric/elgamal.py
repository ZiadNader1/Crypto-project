"""
ElGamal Public-Key Cryptosystem
================================
Proposed by Taher ElGamal (1985), based on the Discrete Logarithm Problem.

Security assumption
-------------------
Given a prime p, a generator g, and y = g^x mod p, it is computationally
infeasible to recover x (the discrete logarithm) for large p.

Domain parameters
-----------------
Uses a safe prime p = 2q+1 (Sophie Germain prime), so the subgroup of order q
has no small subgroups, preventing Pohlig-Hellman and small-subgroup attacks.

Key generation
--------------
    1. Choose safe prime p = 2q+1 and generator g of the subgroup of order q.
    2. Choose private key x ∈ (1, q).
    3. Public key y = g^x mod p.

Encryption of integer m ∈ [1, p-1]
------------------------------------
    1. Choose random ephemeral key k ∈ (1, q).
    2. c1 = g^k mod p
    3. c2 = m · y^k mod p
    Ciphertext = (c1, c2)

Decryption
----------
    1. s     = c1^x mod p       (shared secret)
    2. s_inv = s^(p-2) mod p    (Fermat's little theorem, since p is prime)
    3. m     = c2 · s_inv mod p

Digital Signature (ElGamal scheme)
-----------------------------------
Sign message hash h:
    1. Choose random k with gcd(k, p-1) = 1.
    2. r = g^k mod p
    3. s = k^(-1) · (h - x·r) mod (p-1)
    Signature = (r, s)

Verify signature (r, s) for hash h:
    g^h = y^r · r^s (mod p)

Hybrid encryption (for arbitrary data)
---------------------------------------
    1. Generate random 16-byte session key K.
    2. Encrypt K with ElGamal -> (c1, c2).
    3. Encrypt data with XTEA or IDEA using K.

Complexity
----------
generate_keys(bits=512)  : O(bits^3)  -- safe prime generation dominates
encrypt / decrypt        : O(log^2p)  -- modular exponentiation
sign / verify            : O(log^2p)
Space                    : O(1) per operation (key sizes are O(bits))
"""

from __future__ import annotations

import os
import struct
from dataclasses import dataclass
from typing import NamedTuple

from src.utils.math_utils import (
    generate_safe_prime,
    find_generator,
    mod_inverse,
    gcd,
    hash_to_int,
    is_prime,
)


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class PublicKey:
    p: int          # safe prime modulus
    q: int          # subgroup order  (p = 2q+1)
    g: int          # generator of subgroup of order q
    y: int          # g^x mod p


@dataclass
class PrivateKey:
    p: int
    q: int
    g: int
    x: int          # secret exponent ∈ (1, q)

    @property
    def public_key(self) -> PublicKey:
        return PublicKey(p=self.p, q=self.q, g=self.g, y=pow(self.g, self.x, self.p))


class Ciphertext(NamedTuple):
    c1: int
    c2: int


class Signature(NamedTuple):
    r: int
    s: int


# ---------------------------------------------------------------------------
# Key generation
# ---------------------------------------------------------------------------

def generate_keys(bits: int = 512) -> PrivateKey:
    """Generate an ElGamal key pair.

    bits : bit-length of the prime p (minimum 256 recommended for demos,
           >=2048 for real security).

    Time: O(bits^3) expected for safe-prime generation.
    """
    p, q = generate_safe_prime(bits)
    g = find_generator(p, q)
    # Choose private key x ∈ (2, q-1)
    x = int.from_bytes(os.urandom((bits + 7) // 8), "big") % (q - 2) + 2
    return PrivateKey(p=p, q=q, g=g, x=x)


# ---------------------------------------------------------------------------
# Encryption / Decryption
# ---------------------------------------------------------------------------

def _random_ephemeral(q: int) -> int:
    """Choose a random ephemeral key k ∈ (1, q-1)."""
    bit_len = q.bit_length()
    while True:
        k = int.from_bytes(os.urandom((bit_len + 7) // 8), "big") % (q - 2) + 2
        if k < q:
            return k


def encrypt_int(m: int, pub: PublicKey) -> Ciphertext:
    """Encrypt an integer m ∈ [1, p-1].

    Time: O(log^2p)
    """
    if not (1 <= m < pub.p):
        raise ValueError(f"Message must be in [1, p-1], got {m}")
    k = _random_ephemeral(pub.q)
    c1 = pow(pub.g, k, pub.p)
    c2 = (m * pow(pub.y, k, pub.p)) % pub.p
    return Ciphertext(c1, c2)


def decrypt_int(ct: Ciphertext, priv: PrivateKey) -> int:
    """Decrypt an ElGamal ciphertext.

    Time: O(log^2p)
    """
    s = pow(ct.c1, priv.x, priv.p)
    s_inv = pow(s, priv.p - 2, priv.p)   # Fermat's little theorem
    return (ct.c2 * s_inv) % priv.p


# ---------------------------------------------------------------------------
# Byte-level encryption (hybrid: encrypt a 128-bit session key)
# ---------------------------------------------------------------------------

def encrypt_session_key(session_key: bytes, pub: PublicKey) -> tuple[int, int]:
    """Encrypt a 16-byte session key via ElGamal.

    The session key is encoded as an integer m ∈ [1, p-1].
    Returns (c1, c2) as integers.
    """
    if len(session_key) != 16:
        raise ValueError("Session key must be exactly 16 bytes")
    m = int.from_bytes(session_key, "big")
    if m == 0:
        m = 1   # avoid m=0 (trivial)
    if m >= pub.p:
        raise ValueError("Session key value too large for this key size -- use >=256-bit key")
    ct = encrypt_int(m, pub)
    return ct.c1, ct.c2


def decrypt_session_key(c1: int, c2: int, priv: PrivateKey) -> bytes:
    """Decrypt a session key encrypted with :func:`encrypt_session_key`."""
    m = decrypt_int(Ciphertext(c1, c2), priv)
    return m.to_bytes(16, "big")


# ---------------------------------------------------------------------------
# Digital Signatures
# ---------------------------------------------------------------------------

def sign(message: bytes, priv: PrivateKey) -> Signature:
    """Produce an ElGamal signature over `message`.

    Time: O(log^2p)
    """
    p_minus_1 = priv.p - 1
    h = hash_to_int(message, priv.p)   # hash to Z_p

    while True:
        # k must be coprime to p-1
        k = _random_ephemeral(priv.q)
        if gcd(k, p_minus_1) != 1:
            continue
        r = pow(priv.g, k, priv.p)
        # s = k^{-1} (h - x*r) mod (p-1)
        k_inv = mod_inverse(k, p_minus_1)
        s = (k_inv * (h - priv.x * r)) % p_minus_1
        if s == 0:
            continue
        return Signature(r, s)


def verify(message: bytes, sig: Signature, pub: PublicKey) -> bool:
    """Verify an ElGamal signature.

    Returns True iff the signature is valid.

    Verification equation: g^h = y^r · r^s  (mod p)

    Time: O(log^2p)
    """
    r, s = sig
    if not (1 <= r < pub.p):
        return False
    if not (0 < s < pub.p - 1):
        return False

    h = hash_to_int(message, pub.p)
    lhs = pow(pub.g, h, pub.p)
    rhs = (pow(pub.y, r, pub.p) * pow(r, s, pub.p)) % pub.p
    return lhs == rhs


# ---------------------------------------------------------------------------
# Serialisation helpers (for certificates / network transmission)
# ---------------------------------------------------------------------------

def public_key_to_dict(pub: PublicKey) -> dict:
    return {"p": pub.p, "q": pub.q, "g": pub.g, "y": pub.y}


def public_key_from_dict(d: dict) -> PublicKey:
    return PublicKey(p=d["p"], q=d["q"], g=d["g"], y=d["y"])


def signature_to_dict(sig: Signature) -> dict:
    return {"r": sig.r, "s": sig.s}


def signature_from_dict(d: dict) -> Signature:
    return Signature(r=d["r"], s=d["s"])

"""
Certificate Authority (CA) -- simulates X.509-style PKI
=======================================================

Roles simulated
---------------
Certificate Authority (CA)
    * Holds a root ElGamal key pair.
    * Signs certificates for registered entities (server, clients).
    * Maintains a certificate revocation list (CRL).

Certificate contents
---------------------
    serial_number   : unique integer
    subject         : entity name
    subject_pub_key : entity's ElGamal public key (dict)
    issuer          : CA name
    valid_from      : Unix timestamp (int)
    valid_to        : Unix timestamp (int)
    signature       : ElGamal signature (r, s) over the certificate body hash

Certificate validation
----------------------
1. Check signature against CA public key.
2. Check validity period.
3. Check serial is not in revocation list.

Complexity
----------
issue_certificate   : O(log^2p)  -- one ElGamal sign operation
verify_certificate  : O(log^2p)  -- one ElGamal verify
revoke_certificate  : O(1)
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field

from src.asymmetric.elgamal import (
    PrivateKey,
    PublicKey,
    Signature,
    generate_keys,
    sign,
    verify,
    public_key_to_dict,
    public_key_from_dict,
    signature_to_dict,
    signature_from_dict,
)
from src.utils.math_utils import simple_hash


# ---------------------------------------------------------------------------
# Certificate data structure
# ---------------------------------------------------------------------------

@dataclass
class Certificate:
    serial_number: int
    subject: str
    subject_pub_key: dict            # serialised PublicKey
    issuer: str
    valid_from: int                  # Unix timestamp
    valid_to: int                    # Unix timestamp
    signature: dict | None = None    # serialised Signature (set after signing)

    def body_bytes(self) -> bytes:
        """Canonical byte representation of the certificate body (excluding sig)."""
        body = {
            "serial": self.serial_number,
            "subject": self.subject,
            "subject_pub_key": self.subject_pub_key,
            "issuer": self.issuer,
            "valid_from": self.valid_from,
            "valid_to": self.valid_to,
        }
        return json.dumps(body, sort_keys=True).encode("utf-8")

    def to_dict(self) -> dict:
        return {
            "serial": self.serial_number,
            "subject": self.subject,
            "subject_pub_key": self.subject_pub_key,
            "issuer": self.issuer,
            "valid_from": self.valid_from,
            "valid_to": self.valid_to,
            "signature": self.signature,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Certificate":
        c = cls(
            serial_number=d["serial"],
            subject=d["subject"],
            subject_pub_key=d["subject_pub_key"],
            issuer=d["issuer"],
            valid_from=d["valid_from"],
            valid_to=d["valid_to"],
        )
        c.signature = d.get("signature")
        return c


# ---------------------------------------------------------------------------
# Certificate Authority
# ---------------------------------------------------------------------------

class CertificateAuthority:
    """Simulates a root Certificate Authority.

    Usage::

        ca = CertificateAuthority("HealthCare-Root-CA", key_bits=256)
        cert = ca.issue_certificate("Hospital-Server", server_pub_key, validity_days=365)
        is_valid = ca.verify_certificate(cert)
    """

    def __init__(self, name: str = "Root-CA", key_bits: int = 256) -> None:
        self.name = name
        print(f"[CA] Generating {key_bits}-bit CA key pair...")
        self._priv: PrivateKey = generate_keys(bits=key_bits)
        self.public_key: PublicKey = self._priv.public_key
        self._serial_counter: int = 1000
        self._revoked: set[int] = set()

    # -- certificate issuance --

    def issue_certificate(
        self,
        subject_name: str,
        subject_pub_key: PublicKey,
        validity_days: int = 365,
    ) -> Certificate:
        """Issue and sign a certificate for `subject_name`.

        Time: O(log^2p) for signature generation.
        """
        self._serial_counter += 1
        now = int(time.time())
        cert = Certificate(
            serial_number=self._serial_counter,
            subject=subject_name,
            subject_pub_key=public_key_to_dict(subject_pub_key),
            issuer=self.name,
            valid_from=now,
            valid_to=now + validity_days * 86400,
        )
        sig = sign(cert.body_bytes(), self._priv)
        cert.signature = signature_to_dict(sig)
        print(f"[CA] Issued certificate #{cert.serial_number} for '{subject_name}'")
        return cert

    # -- verification --

    def verify_certificate(self, cert: Certificate) -> bool:
        """Return True iff the certificate is valid, unexpired, and not revoked.

        Time: O(log^2p) for signature verification.
        """
        # Check revocation
        if cert.serial_number in self._revoked:
            return False

        # Check validity period
        now = int(time.time())
        if not (cert.valid_from <= now <= cert.valid_to):
            return False

        # Check signature
        if cert.signature is None:
            return False
        sig = signature_from_dict(cert.signature)
        return verify(cert.body_bytes(), sig, self.public_key)

    # -- revocation --

    def revoke_certificate(self, serial_number: int) -> None:
        """Add a certificate serial to the revocation list.  O(1)."""
        self._revoked.add(serial_number)
        print(f"[CA] Certificate #{serial_number} revoked")

    @property
    def revoked_serials(self) -> set[int]:
        return frozenset(self._revoked)

    # -- helper: fingerprint --

    @staticmethod
    def certificate_fingerprint(cert: Certificate) -> str:
        """Hex fingerprint of the certificate body."""
        raw = simple_hash(cert.body_bytes(), digest_size=16)
        return raw.hex()

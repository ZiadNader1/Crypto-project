# Network layer -- TCP client/server for the secure healthcare portal.

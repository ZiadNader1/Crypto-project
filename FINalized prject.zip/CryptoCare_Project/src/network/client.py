"""
Network Client
==============

``NetworkClient`` wraps ``SecureClient`` and communicates with
``NetworkServer`` over a real TCP socket.

Usage
-----
::

    from src.network.client import NetworkClient

    client = NetworkClient(name="Patient-Jane", host="127.0.0.1", port=9999)
    client.connect()           # handshake + PQC auth
    path = client.upload("record_name", b"my medical data")
    data = client.download(path)
    client.disconnect()

All plaintext data is XTEA-encrypted **before** being sent over the socket
(via the underlying ``SecureClient.send_message``).  The server never sees
unencrypted application data.
"""

from __future__ import annotations

import socket

from src.ca.certificate_authority import Certificate, CertificateAuthority
from src.app.secure_session import SecureClient
from src.network.protocol import send_msg, recv_msg


class NetworkClient:
    """TCP client wrapping ``SecureClient``.

    Parameters
    ----------
    name     : Human-readable client identifier (used for PQC auth).
    ca       : The shared ``CertificateAuthority`` instance.  In a real
               deployment this would be a pre-distributed CA certificate;
               here the caller passes the same CA object for simplicity.
    host     : Server host (default ``"127.0.0.1"``).
    port     : Server TCP port (default ``9999``).
    key_bits : ElGamal key size in bits (default ``256``).
    """

    def __init__(
        self,
        name: str,
        ca: CertificateAuthority,
        host: str = "127.0.0.1",
        port: int = 9999,
        key_bits: int = 256,
        bootstrap: bool = False,
    ) -> None:
        self.name      = name
        self._ca       = ca
        self.host      = host
        self.port      = port
        self._bootstrap = bootstrap

        print(f"\n[{name}] Generating {key_bits}-bit ElGamal key pair...")
        self._secure_client = SecureClient(name=name, ca=ca, key_bits=key_bits)
        self._sock: socket.socket | None = None
        self._session_id: str | None = None

    # -- Connection lifecycle -----------------------------------------------

    def connect(self) -> None:
        """Open TCP connection and run the full handshake + PQC auth."""
        self._sock = socket.create_connection((self.host, self.port))
        print(f"[{self.name}] Connected to {self.host}:{self.port}")
        if self._bootstrap:
            self._do_bootstrap()
        self._handshake()

    def disconnect(self) -> None:
        """Send DISCONNECT and close the socket."""
        if self._sock:
            try:
                send_msg(self._sock, {"type": "DISCONNECT"})
            except OSError:
                pass
            finally:
                self._sock.close()
                self._sock = None
        self._session_id = None
        print(f"[{self.name}] Disconnected.")

    # -- Upload / Download -------------------------------------------------

    def upload(self, record_name: str, plaintext: bytes) -> str:
        """Encrypt *plaintext* with XTEA and send it to the server.

        Returns the server-side storage path of the encrypted record.
        """
        self._require_session()
        ct = self._secure_client.send_message(plaintext)
        print(f"[{self.name}] UPLOAD '{record_name}': "
              f"{len(plaintext)} B -> {len(ct)} B ciphertext")
        send_msg(self._sock, {
            "type":        "UPLOAD",
            "record_name": record_name,
            "ciphertext":  ct.hex(),
        })

        # Receive ACK (and handle optional key rotation notice)
        response = self._read_until_ack("UPLOAD_ACK")
        return response["path"]

    def download(self, path: str) -> bytes:
        """Request a record by *path* and decrypt the XTEA ciphertext.

        Returns the original plaintext bytes.
        """
        self._require_session()
        send_msg(self._sock, {"type": "DOWNLOAD", "path": path})

        response = self._read_until_ack("DOWNLOAD_DATA")
        ct = bytes.fromhex(response["ciphertext"])
        plaintext = self._secure_client.receive_message(ct)
        print(f"[{self.name}] DOWNLOAD: {len(ct)} B ciphertext -> "
              f"{len(plaintext)} B plaintext OK")
        return plaintext

    # -- Internal helpers ---------------------------------------------------

    def _do_bootstrap(self) -> None:
        """Step 0 (standalone mode): get a CA-signed cert from the server.

        Sends the client's ElGamal public key; receives:
        - The CA public key (to verify the server certificate later).
        - A freshly issued client certificate signed by the server's CA.

        After this call, ``self._secure_client.certificate`` is replaced with
        the server-issued certificate and ``self._ca.public_key`` is updated
        with the server's CA public key, so the subsequent handshake verifies.
        """
        from src.asymmetric.elgamal import public_key_to_dict, public_key_from_dict
        from src.ca.certificate_authority import Certificate

        send_msg(self._sock, {
            "type":    "BOOTSTRAP",
            "name":    self.name,
            "pub_key": public_key_to_dict(self._secure_client.pub),
        })
        print(f"[{self.name}] BOOTSTRAP sent -- waiting for CA certificate...")

        resp = recv_msg(self._sock)
        if resp.get("type") == "ERROR":
            raise RuntimeError(f"Bootstrap failed: {resp['detail']}")
        if resp.get("type") != "BOOTSTRAP_RESP":
            raise RuntimeError(f"Unexpected bootstrap response: {resp.get('type')}")

        # Update the CA verifier with the server's real public key
        server_ca_pub   = public_key_from_dict(resp["ca_pub_key"])
        self._ca.public_key = server_ca_pub
        self._ca.name       = resp["ca_name"]

        # Replace the local (wrong-CA) cert with the server-issued one
        self._secure_client.certificate = Certificate.from_dict(resp["client_cert"])
        print(f"[{self.name}] BOOTSTRAP_RESP -- "
              f"cert #{self._secure_client.certificate.serial_number} issued OK")

    def _handshake(self) -> None:
        """Steps 1-4: mutual auth + session key + PQC auth."""

        # Step 1: CLIENT_HELLO
        hello = self._secure_client.initiate_handshake()
        send_msg(self._sock, {"type": "CLIENT_HELLO", **hello})
        print(f"[{self.name}] CLIENT_HELLO sent")

        # Step 2: SERVER_HELLO
        response = recv_msg(self._sock)
        if response.get("type") == "ERROR":
            raise RuntimeError(f"Server rejected handshake: {response['detail']}")
        if response.get("type") != "SERVER_HELLO":
            raise RuntimeError(f"Unexpected message: {response.get('type')}")

        session = self._secure_client.process_server_hello(response)
        self._session_id = response["session_id"]
        print(f"[{self.name}] Session established OK  "
              f"key={session.session_key.hex()[:16]}...  "
              f"session={self._session_id}")

        # Step 3: PQC_AUTH
        send_msg(self._sock, {"type": "PQC_AUTH", "name": self.name})

        # Step 4: PQC_AUTH_RESULT
        result = recv_msg(self._sock)
        if result.get("type") != "PQC_AUTH_RESULT":
            raise RuntimeError(f"Unexpected message after PQC_AUTH: {result}")
        if not result.get("ok"):
            raise RuntimeError("PQC authentication FAILED -- aborting")
        print(f"[{self.name}] PQC authentication PASSED OK")

    def _read_until_ack(self, expected_type: str) -> dict:
        """Read messages, handling interleaved ROTATE_KEY frames.

        Key-rotation notices can arrive between an UPLOAD request and its
        UPLOAD_ACK, so we consume them here before returning the real ACK.
        """
        while True:
            msg = recv_msg(self._sock)
            msg_type = msg.get("type")

            if msg_type == "ROTATE_KEY":
                new_key = bytes.fromhex(msg["new_key"])
                self._secure_client.update_session_key(new_key)
                print(f"[{self.name}] Session key rotated OK")
                continue   # wait for the next frame

            if msg_type == "ERROR":
                raise RuntimeError(f"Server error: {msg.get('detail')}")

            if msg_type != expected_type:
                raise RuntimeError(
                    f"Expected {expected_type!r}, got {msg_type!r}"
                )

            return msg

    def _require_session(self) -> None:
        if self._sock is None or self._session_id is None:
            raise RuntimeError("Not connected -- call connect() first")

    # -- Context manager support -------------------------------------------

    def __enter__(self) -> "NetworkClient":
        self.connect()
        return self

    def __exit__(self, *_) -> None:
        self.disconnect()

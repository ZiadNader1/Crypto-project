"""
TCP Message Protocol
====================

Every message is a **length-prefixed JSON frame**:

    [ 4 bytes: big-endian uint32 -- length of JSON payload ]
    [ N bytes: UTF-8 encoded JSON ]

Why JSON?
---------
All handshake data (certificates, ElGamal ciphertexts, signatures) is already
serialised to/from plain Python dicts in the existing code.  JSON is therefore
a natural wire format.

Big-integer handling
--------------------
JSON numbers are limited to IEEE-754 doubles (~53 bits).  ElGamal values
(p, q, g, y, c1, c2, r, s) can be hundreds of bits.  We encode them as
decimal strings and tag them with a ``__bigint__`` wrapper so the decoder
can reconstruct them transparently:

    {"__bigint__": "12345678901234567890"}

The helpers ``encode_payload`` / ``decode_payload`` walk the dict tree and
apply this conversion automatically, so the rest of the code works with
ordinary Python ints.

Message types (string constants used as ``msg["type"]``)
---------------------------------------------------------
CLIENT_HELLO     -- client sends its certificate
SERVER_HELLO     -- server responds with its cert + encrypted session key
PQC_AUTH         -- client requests PQC authentication
PQC_AUTH_RESULT  -- server returns True/False
UPLOAD           -- client sends an encrypted record
UPLOAD_ACK       -- server confirms storage path
DOWNLOAD         -- client requests a stored record
DOWNLOAD_DATA    -- server returns the encrypted record
ROTATE_KEY       -- server notifies of a new session key
DISCONNECT       -- polite close
ERROR            -- server signals a protocol error
"""

from __future__ import annotations

import json
import socket
import struct
from typing import Any


# ---------------------------------------------------------------------------
# Big-integer serialisation helpers
# ---------------------------------------------------------------------------

def _encode_value(v: Any) -> Any:
    """Recursively encode Python ints as ``{"__bigint__": "..."}`` wrappers."""
    if isinstance(v, int) and not isinstance(v, bool):
        return {"__bigint__": str(v)}
    if isinstance(v, dict):
        return {k: _encode_value(val) for k, val in v.items()}
    if isinstance(v, (list, tuple)):
        return [_encode_value(x) for x in v]
    return v


def _decode_value(v: Any) -> Any:
    """Recursively restore ``{"__bigint__": "..."}`` wrappers to Python ints."""
    if isinstance(v, dict):
        if set(v.keys()) == {"__bigint__"}:
            return int(v["__bigint__"])
        return {k: _decode_value(val) for k, val in v.items()}
    if isinstance(v, list):
        return [_decode_value(x) for x in v]
    return v


def encode_payload(payload: dict) -> bytes:
    """Serialise a payload dict to UTF-8 JSON bytes (big-ints safe)."""
    return json.dumps(_encode_value(payload), separators=(",", ":")).encode("utf-8")


def decode_payload(data: bytes) -> dict:
    """Deserialise JSON bytes back to a payload dict (big-ints restored)."""
    return _decode_value(json.loads(data.decode("utf-8")))


# ---------------------------------------------------------------------------
# Frame send / receive
# ---------------------------------------------------------------------------

def send_msg(sock: socket.socket, payload: dict) -> None:
    """Send a length-prefixed JSON message over *sock*.

    Frame layout::

        [4B length][JSON bytes]
    """
    body = encode_payload(payload)
    header = struct.pack(">I", len(body))
    # sendall guarantees the full buffer is written even on partial sends.
    sock.sendall(header + body)


def recv_msg(sock: socket.socket) -> dict:
    """Receive a length-prefixed JSON message from *sock*.

    Blocks until a complete frame is available.
    Raises ``ConnectionError`` if the socket closes mid-frame.
    """
    header = _recv_exactly(sock, 4)
    length = struct.unpack(">I", header)[0]
    body = _recv_exactly(sock, length)
    return decode_payload(body)


def _recv_exactly(sock: socket.socket, n: int) -> bytes:
    """Read exactly *n* bytes from *sock*, handling partial reads."""
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            raise ConnectionError(
                f"Socket closed after {len(buf)} of {n} expected bytes"
            )
        buf.extend(chunk)
    return bytes(buf)

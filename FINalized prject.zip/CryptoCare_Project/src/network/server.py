"""
Network Server
==============

``NetworkServer`` listens on a TCP socket and handles each incoming client
connection in a dedicated thread.

Per-connection protocol (TLS-style handshake + data exchange)
--------------------------------------------------------------

Step  Direction            Message type        Contents
----  -------------------  ------------------  ----------------------------
 0*   Client -> Server      BOOTSTRAP           {"name": str,
                                                "pub_key": dict}   (*optional)
 0*   Server -> Client      BOOTSTRAP_RESP      {"ca_pub_key": dict,
                                                "ca_name": str,
                                                "client_cert": dict}
 1    Client -> Server      CLIENT_HELLO        client certificate (dict)
 2    Server -> Client      SERVER_HELLO        server cert, enc. session key,
                                               signature, session_id
 3    Client -> Server      PQC_AUTH            {"name": client_name}
 4    Server -> Client      PQC_AUTH_RESULT     {"ok": true|false}
 5+   Client -> Server      UPLOAD              {"record_name": str,
                                                "ciphertext": hex-string}
 5+   Server -> Client      UPLOAD_ACK          {"path": str}
 5+   Client -> Server      DOWNLOAD            {"path": str}
 5+   Server -> Client      DOWNLOAD_DATA       {"ciphertext": hex-string}
  N   Client -> Server      DISCONNECT          {}
      Server -> Client      ERROR               {"detail": str}

Step 0 (BOOTSTRAP) is optional.  It is used by standalone client processes
that do not share the CA object in-memory.  The server issues a certificate
for the client and returns the CA public key so the client can verify the
server's certificate.

Ciphertext on the wire
-----------------------
The client XTEA-encrypts the plaintext **before** sending (same as the
in-process ``SecureClient.send_message``).  The raw ciphertext bytes are
hex-encoded for JSON transport.  The server decrypts with ``receive_message``,
stores at rest with IDEA, and reverses the process on download.

Usage
-----
::

    from src.network.server import NetworkServer

    srv = NetworkServer(host="127.0.0.1", port=9999, key_bits=256)
    srv.start()          # blocking -- runs until KeyboardInterrupt
"""

from __future__ import annotations

import socket
import threading
import traceback
import uuid

from src.ca.certificate_authority import Certificate, CertificateAuthority
from src.app.secure_session import SecureServer
from src.pqc.lwe import (
    generate_keys as lwe_generate_keys,
    generate_auth_token,
    verify_auth_token,
)
from src.network.protocol import send_msg, recv_msg


class NetworkServer:
    """TCP server wrapping ``SecureServer`` + CA.

    Parameters
    ----------
    host     : Interface to bind (default ``"127.0.0.1"``).
    port     : TCP port (default ``9999``).
    key_bits : ElGamal key size in bits (default ``256``).
    storage_dir : Directory for encrypted at-rest records.
                  Defaults to a temp dir managed by the OS.
    """

    BACKLOG = 5   # max queued TCP connections

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 9999,
        key_bits: int = 256,
        storage_dir: str | None = None,
    ) -> None:
        self.host = host
        self.port = port

        import tempfile, os
        self.storage_dir = storage_dir or tempfile.mkdtemp(prefix="healthcare_net_")
        os.makedirs(self.storage_dir, exist_ok=True)

        # -- Crypto setup --------------------------------------------------
        print(f"\n[Server] Initialising Certificate Authority...")
        self.ca = CertificateAuthority(name="HealthCare-Root-CA", key_bits=key_bits)

        print(f"[Server] Registering Hospital-Server with CA...")
        self._secure_server = SecureServer(
            name="Hospital-Server", ca=self.ca, key_bits=key_bits
        )

        print(f"[Server] Generating Post-Quantum (Ring-LWE) key pair...")
        self._pqc_priv = lwe_generate_keys()
        self._pqc_pub  = self._pqc_priv.pub
        print("[Server] Ring-LWE key pair ready.")

        # -- Session -> client-name mapping (for logging) -------------------
        self._sessions: dict[str, str] = {}
        self._lock = threading.Lock()

    # -- Public interface --------------------------------------------------

    def start(self) -> None:
        """Bind the socket and accept connections (blocking)."""
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv_sock:
            srv_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            srv_sock.bind((self.host, self.port))
            srv_sock.listen(self.BACKLOG)
            print(f"\n[Server] Listening on {self.host}:{self.port}  (Ctrl-C to stop)\n")
            while True:
                try:
                    conn, addr = srv_sock.accept()
                    print(f"[Server] New connection from {addr}")
                    t = threading.Thread(
                        target=self._handle_client,
                        args=(conn, addr),
                        daemon=True,
                    )
                    t.start()
                except KeyboardInterrupt:
                    print("\n[Server] Shutting down.")
                    break

    def start_background(self, ready_event: threading.Event | None = None) -> threading.Thread:
        """Start the server in a background daemon thread (for testing).

        Parameters
        ----------
        ready_event : If supplied, ``.set()`` is called once the socket is
                      bound and listening.  Use this to avoid race conditions
                      in tests.
        """
        t = threading.Thread(target=self._background_start, args=(ready_event,), daemon=True)
        t.start()
        return t

    def _background_start(self, ready_event: threading.Event | None) -> None:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv_sock:
            srv_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            srv_sock.bind((self.host, self.port))
            srv_sock.listen(self.BACKLOG)
            if ready_event:
                ready_event.set()
            while True:
                try:
                    conn, addr = srv_sock.accept()
                    t = threading.Thread(
                        target=self._handle_client,
                        args=(conn, addr),
                        daemon=True,
                    )
                    t.start()
                except OSError:
                    break   # socket closed from outside (test teardown)

    # -- Per-client handler -------------------------------------------------

    def _handle_client(self, conn: socket.socket, addr) -> None:
        session_id: str | None = None
        try:
            with conn:
                session_id = self._handshake(conn)
                if session_id is None:
                    return
                self._message_loop(conn, session_id)
        except ConnectionError as exc:
            print(f"[Server] Connection from {addr} closed: {exc}")
        except Exception:
            print(f"[Server] Unhandled error for {addr}:")
            traceback.print_exc()
        finally:
            if session_id:
                name = self._sessions.pop(session_id, "?")
                print(f"[Server] Session {session_id} ({name}) ended.")

    def _handshake(self, conn: socket.socket) -> str | None:
        """Steps 0-4: optional bootstrap + mutual auth + session key + PQC auth."""
        from src.asymmetric.elgamal import public_key_from_dict, public_key_to_dict

        # -- Step 0 (optional): BOOTSTRAP --------------------------------
        # Peek at the first message type without consuming it fully.
        msg = recv_msg(conn)

        if msg.get("type") == "BOOTSTRAP":
            client_name = msg.get("name", "unknown")
            client_pub  = public_key_from_dict(msg["pub_key"])
            print(f"[Server] BOOTSTRAP from '{client_name}' -- issuing certificate...")

            # Issue a CA-signed certificate for the bootstrapping client
            client_cert = self.ca.issue_certificate(client_name, client_pub)

            send_msg(conn, {
                "type":        "BOOTSTRAP_RESP",
                "ca_pub_key":  public_key_to_dict(self.ca.public_key),
                "ca_name":     self.ca.name,
                "client_cert": client_cert.to_dict(),
            })
            print(f"[Server] BOOTSTRAP_RESP sent -- cert #{client_cert.serial_number}")

            # Now read the real CLIENT_HELLO
            msg = recv_msg(conn)

        # -- Step 1: CLIENT_HELLO -----------------------------------------
        if msg.get("type") != "CLIENT_HELLO":
            send_msg(conn, {"type": "ERROR", "detail": "Expected CLIENT_HELLO"})
            return None

        client_cert = Certificate.from_dict(msg["client_cert"])
        session_id  = str(uuid.uuid4())[:8]
        print(f"[Server] CLIENT_HELLO from '{client_cert.subject}' "
              f"(cert #{client_cert.serial_number}), session={session_id}")

        # -- Step 2: SERVER_HELLO -----------------------------------------
        try:
            server_hello = self._secure_server.prepare_server_hello(
                client_cert, session_id
            )
        except ValueError as exc:
            send_msg(conn, {"type": "ERROR", "detail": str(exc)})
            return None

        send_msg(conn, {"type": "SERVER_HELLO", **server_hello})
        print(f"[Server] SERVER_HELLO sent (session={session_id})")

        # -- Step 3: PQC_AUTH ---------------------------------------------
        msg = recv_msg(conn)
        if msg.get("type") != "PQC_AUTH":
            send_msg(conn, {"type": "ERROR", "detail": "Expected PQC_AUTH"})
            return None

        client_name = msg.get("name", "")
        token       = generate_auth_token(client_name, self._pqc_pub)
        ok          = verify_auth_token(token, client_name, self._pqc_priv)
        print(f"[Server] PQC auth for '{client_name}': {'PASSED OK' if ok else 'FAILED FAIL'}")

        # -- Step 4: PQC_AUTH_RESULT ---------------------------------------
        send_msg(conn, {"type": "PQC_AUTH_RESULT", "ok": ok})

        if not ok:
            return None

        with self._lock:
            self._sessions[session_id] = client_name

        return session_id

    def _message_loop(self, conn: socket.socket, session_id: str) -> None:
        """Steps 5+: handle UPLOAD / DOWNLOAD / DISCONNECT messages."""
        import os

        while True:
            msg = recv_msg(conn)
            msg_type = msg.get("type")

            if msg_type == "DISCONNECT":
                print(f"[Server] DISCONNECT from session {session_id}")
                break

            elif msg_type == "UPLOAD":
                record_name = msg["record_name"]
                ct_transit  = bytes.fromhex(msg["ciphertext"])

                # Decrypt from transit (XTEA), re-encrypt at rest (IDEA)
                plaintext = self._secure_server.receive_message(session_id, ct_transit)
                record_path = os.path.join(
                    self.storage_dir, f"{session_id}_{record_name}.enc"
                )
                self._secure_server.store_record(session_id, plaintext, record_path)
                print(f"[Server] UPLOAD '{record_name}' stored -> {record_path}")

                send_msg(conn, {"type": "UPLOAD_ACK", "path": record_path})

                # Key rotation if threshold reached
                session = self._secure_server.get_session(session_id)
                if session and session.messages_sent % 5 == 0:
                    new_key = self._secure_server.rotate_session_key(session_id)
                    send_msg(conn, {
                        "type": "ROTATE_KEY",
                        "new_key": new_key.hex(),
                    })
                    print(f"[Server] Session key rotated for {session_id}")

            elif msg_type == "DOWNLOAD":
                record_path = msg["path"]
                try:
                    plaintext  = self._secure_server.load_record(session_id, record_path)
                    ct_transit = self._secure_server.send_message(session_id, plaintext)
                    print(f"[Server] DOWNLOAD '{os.path.basename(record_path)}' "
                          f"-> {len(ct_transit)} B ciphertext")
                    send_msg(conn, {
                        "type": "DOWNLOAD_DATA",
                        "ciphertext": ct_transit.hex(),
                    })
                except (FileNotFoundError, KeyError) as exc:
                    send_msg(conn, {"type": "ERROR", "detail": str(exc)})

            else:
                send_msg(conn, {
                    "type": "ERROR",
                    "detail": f"Unknown message type: {msg_type!r}",
                })

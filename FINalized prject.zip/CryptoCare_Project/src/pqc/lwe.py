"""
Ring-LWE Based Public-Key Encryption (Post-Quantum Bonus)
==========================================================
Inspired by the CRYSTALS-Kyber design (NIST PQC standard), simplified for
educational purposes.

Background -- Learning With Errors (LWE)
----------------------------------------
The Learning With Errors problem asks: given (A, b = As + e mod q) where
A is a random matrix and e is a small "error" vector, recover s.
This is believed hard even for quantum computers.

Ring-LWE operates in the polynomial ring R_q = Z_q[x]/(x^n + 1), which
makes all operations polynomial multiplications -- far more efficient than
plain LWE matrices.

Parameters used (toy/educational -- NOT production-secure)
----------------------------------------------------------
n : 16   polynomial degree (production Kyber-512 uses n=256)
q : 257  prime modulus -- gives HALF_Q=128, well above max error ~= 33
sigma : 1    error standard deviation (small errors drawn from {-1,0,1})

Key generation
--------------
    s  <- small polynomial (coefficients in {-1, 0, 1})
    e  <- small error polynomial
    a  <- random polynomial mod q
    b  = a·s + e  mod q       (public key = (a, b))
    Private key = s

Encryption of a single bit m ∈ {0, 1}
---------------------------------------
    r  <- small random polynomial
    e1 <- small error polynomial
    e2 <- small error scalar
    u  = a·r + e1  mod q
    v  = b·r + e2 + round(q/2)·m  mod q
    Ciphertext = (u, v)

Decryption
----------
    d  = v - s·u  mod q      (~= e2 + e1·s + round(q/2)·m)
    m  = 1 if |d mod q| > q/4 else 0   (rounding)

For multi-bit messages, encode each bit independently and concatenate.

Complexity
----------
poly_mul      : O(n^2)       (schoolbook; NTT would give O(n log n))
key_gen       : O(n^2)
encrypt_bit   : O(n^2)
decrypt_bit   : O(n^2)
encrypt_bytes : O(n^2 · 8 · |data|)
Space         : O(n) per polynomial
"""

from __future__ import annotations

import os
import random
from dataclasses import dataclass


# ---------------------------------------------------------------------------
# Parameters
# ---------------------------------------------------------------------------

N: int = 16          # polynomial degree  (x^N + 1)
Q: int = 257         # prime modulus -- chosen so HALF_Q=128 >> max_error~=33
HALF_Q: int = Q // 2


# ---------------------------------------------------------------------------
# Polynomial arithmetic in Z_q[x]/(x^N + 1)
# ---------------------------------------------------------------------------

Poly = list[int]     # always length N


def _zero() -> Poly:
    return [0] * N


def _reduce(p: Poly) -> Poly:
    """Reduce each coefficient mod Q."""
    return [c % Q for c in p]


def _poly_add(a: Poly, b: Poly) -> Poly:
    """Coefficient-wise addition mod Q.  O(N)"""
    return [(a[i] + b[i]) % Q for i in range(N)]


def _poly_sub(a: Poly, b: Poly) -> Poly:
    """Coefficient-wise subtraction mod Q.  O(N)"""
    return [(a[i] - b[i]) % Q for i in range(N)]


def _poly_mul(a: Poly, b: Poly) -> Poly:
    """Schoolbook polynomial multiplication in Z_q[x]/(x^N + 1).

    Reduction rule: x^N = -1, so x^(N+k) = -x^k.

    Time: O(N^2)
    """
    result = [0] * N
    for i in range(N):
        for j in range(N):
            idx = i + j
            if idx < N:
                result[idx] = (result[idx] + a[i] * b[j]) % Q
            else:
                # x^N = -1 -> x^(N+k) = -x^k
                result[idx - N] = (result[idx - N] - a[i] * b[j]) % Q
    return result


def _small_poly(size: int = N) -> Poly:
    """Sample a polynomial with coefficients in {-1, 0, 1} (centered binomial)."""
    coeffs = []
    for _ in range(size):
        # Sum of two uniform bits minus 1 -> {-1, 0, 0, 1} approximates Gaussian
        coin = random.randint(0, 3)
        c = (coin >> 1) - (coin & 1)   # ∈ {-1, 0, 1}
        coeffs.append(c % Q)
    return coeffs


def _random_poly() -> Poly:
    """Sample a uniformly random polynomial mod Q."""
    return [random.randint(0, Q - 1) for _ in range(N)]


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class LWEPublicKey:
    a: Poly          # random polynomial
    b: Poly          # b = a·s + e


@dataclass
class LWEPrivateKey:
    s: Poly          # secret small polynomial
    pub: LWEPublicKey


# ---------------------------------------------------------------------------
# Key generation
# ---------------------------------------------------------------------------

def generate_keys() -> LWEPrivateKey:
    """Generate a Ring-LWE key pair.

    Returns a PrivateKey whose .pub attribute is the corresponding public key.

    Time: O(N^2)
    """
    a = _random_poly()
    s = _small_poly()          # secret
    e = _small_poly()          # error

    # b = a·s + e  mod q
    b = _poly_add(_poly_mul(a, s), e)

    pub = LWEPublicKey(a=a, b=b)
    return LWEPrivateKey(s=s, pub=pub)


# ---------------------------------------------------------------------------
# Bit encryption / decryption
# ---------------------------------------------------------------------------

def _encrypt_bit(bit: int, pub: LWEPublicKey) -> tuple[Poly, int]:
    """Encrypt a single bit (0 or 1).

    Returns (u_poly, v_scalar) where u is a polynomial and v is an integer.

    Time: O(N^2)
    """
    r  = _small_poly()
    e1 = _small_poly()
    e2 = random.randint(-1, 1) % Q      # small scalar error

    # u = a·r + e1  mod q
    u = _poly_add(_poly_mul(pub.a, r), e1)

    # v uses only the constant term (coeff[0]) of b·r to avoid error amplification
    # from summing N noisy coefficients. This keeps the error term bounded by
    # ±(N + N + 1) = ±33  which is << HALF_Q//2 = 64.
    br = _poly_mul(pub.b, r)
    v_int = (br[0] + e2 + (HALF_Q * bit)) % Q

    return u, v_int


def _decrypt_bit(u: Poly, v: int, priv: LWEPrivateKey) -> int:
    """Decrypt a single bit.

    d = v - (s·u)[0]  mod q
    bit = 1 if d is closer to HALF_Q than to 0 else 0

    Time: O(N^2)
    """
    su = _poly_mul(priv.s, u)
    d = (v - su[0]) % Q  # use constant term only

    # Round: d near 0 -> bit=0, d near HALF_Q -> bit=1
    dist_zero = min(d, Q - d)
    dist_half = min(abs(d - HALF_Q), Q - abs(d - HALF_Q))
    return 1 if dist_half < dist_zero else 0


# ---------------------------------------------------------------------------
# Byte-level API
# ---------------------------------------------------------------------------

@dataclass
class LWECiphertext:
    u_polys: list[Poly]       # one polynomial per bit
    v_scalars: list[int]      # one scalar per bit


def encrypt_bytes(data: bytes, pub: LWEPublicKey) -> LWECiphertext:
    """Encrypt bytes bit-by-bit using Ring-LWE.

    Time: O(N^2 · 8 · len(data))
    """
    u_polys: list[Poly] = []
    v_scalars: list[int] = []

    for byte in data:
        for bit_pos in range(7, -1, -1):   # MSB first
            bit = (byte >> bit_pos) & 1
            u, v = _encrypt_bit(bit, pub)
            u_polys.append(u)
            v_scalars.append(v)

    return LWECiphertext(u_polys=u_polys, v_scalars=v_scalars)


def decrypt_bytes(ct: LWECiphertext, priv: LWEPrivateKey) -> bytes:
    """Decrypt bytes from a Ring-LWE ciphertext.

    Time: O(N^2 · 8 · len(plaintext))
    """
    bits = [
        _decrypt_bit(u, v, priv)
        for u, v in zip(ct.u_polys, ct.v_scalars)
    ]

    # Pack bits into bytes
    if len(bits) % 8 != 0:
        raise ValueError("Ciphertext bit count is not a multiple of 8")

    result: list[int] = []
    for i in range(0, len(bits), 8):
        byte = 0
        for j in range(8):
            byte = (byte << 1) | bits[i + j]
        result.append(byte)

    return bytes(result)


# ---------------------------------------------------------------------------
# Demo-level authentication token
# ---------------------------------------------------------------------------

def generate_auth_token(user_id: str, pub: LWEPublicKey) -> LWECiphertext:
    """Encrypt a UTF-8 user identifier as a PQC authentication token."""
    data = user_id.encode("utf-8")
    return encrypt_bytes(data, pub)


def verify_auth_token(
    token: LWECiphertext,
    expected_user_id: str,
    priv: LWEPrivateKey,
) -> bool:
    """Decrypt and verify a PQC authentication token."""
    try:
        recovered = decrypt_bytes(token, priv)
        return recovered.decode("utf-8") == expected_user_id
    except Exception:
        return False

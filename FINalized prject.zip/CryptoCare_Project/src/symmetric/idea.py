"""
IDEA -- International Data Encryption Algorithm
===============================================
Designed by Xuejia Lai and James L. Massey (1991).

Properties
----------
Block size   : 64 bits  (four 16-bit sub-blocks)
Key size     : 128 bits -> 52 x 16-bit subkeys via rotation schedule
Rounds       : 8 full rounds + 1 output transformation
Mode         : CBC with PKCS#7 padding
Operations   : Three algebraically incompatible group operations
               * XOR             (⊕)  -- group (Z2)¹⁶
               * Addition mod 2¹⁶    (⊞)  -- group Z_{2¹⁶}
               * Multiplication mod (2¹⁶+1) = 65537  (⊗)  -- group Z*_{65537}
                 (0 treated as 2¹⁶ for multiplication; 0 result -> 0)

Key Schedule (52 subkeys)
-------------------------
The 128-bit key is split into 8 x 16-bit words (first 8 subkeys).
Rotate the 128-bit key left by 25 bits, extract next 8 subkeys.
Repeat until 52 subkeys collected.

One Full Round (subkeys K1...K6):
    a = X1 ⊗ K1
    b = X2 ⊞ K2
    c = X3 ⊞ K3
    d = X4 ⊗ K4
    e = (a ⊕ c) ⊗ K5
    f = (b ⊕ d) ⊞ e
    g = f ⊗ K6
    h = e ⊞ g
    Y1 = a ⊕ g
    Y2 = c ⊕ g      <- middle two are swapped between rounds
    Y3 = b ⊕ h
    Y4 = d ⊕ h

Output transformation (K49...K52):
    Y1 = X1 ⊗ K49,  Y2 = X2 ⊞ K50,  Y3 = X3 ⊞ K51,  Y4 = X4 ⊗ K52
    (using un-swapped inputs from round 8)

Decryption uses the same structure with inverted subkeys.

Complexity
----------
encrypt_block / decrypt_block : O(1)
encrypt / decrypt (n bytes)   : O(n)
Space                         : O(1) state + O(n) output
"""

from __future__ import annotations

import os
import struct


_BLOCK_BYTES: int = 8
_KEY_BYTES: int = 16
_ROUNDS: int = 8
_MOD_MUL: int = 65537      # 2^16 + 1  (prime)
_MOD_ADD: int = 65536      # 2^16
_MASK16: int = 0xFFFF


# ---------------------------------------------------------------------------
# The three group operations
# ---------------------------------------------------------------------------

def _mul(a: int, b: int) -> int:
    """Multiplication mod (2¹⁶ + 1) with 0 ↔ 2¹⁶ convention."""
    if a == 0:
        a = _MOD_ADD       # 0 represents 2^16
    if b == 0:
        b = _MOD_ADD
    result = (a * b) % _MOD_MUL
    return 0 if result == _MOD_ADD else result


def _add(a: int, b: int) -> int:
    """Addition mod 2¹⁶."""
    return (a + b) & _MASK16


def _mul_inv(a: int) -> int:
    """Multiplicative inverse of a mod (2¹⁶ + 1).

    Since 65537 is prime and a ∈ Z*_{65537}, a^{65535} = a^{-1} (Fermat).
    Special case: inv(0) = 0.
    """
    if a == 0:
        return 0
    if a == 1:
        return 1
    # Extended Euclidean on (a, 65537)
    t, new_t = 0, 1
    r, new_r = _MOD_MUL, a
    while new_r != 0:
        quotient = r // new_r
        t, new_t = new_t, t - quotient * new_t
        r, new_r = new_r, r - quotient * new_r
    if t < 0:
        t += _MOD_MUL
    return t


def _add_inv(a: int) -> int:
    """Additive inverse of a mod 2¹⁶."""
    return (- a) & _MASK16


# ---------------------------------------------------------------------------
# Key schedule
# ---------------------------------------------------------------------------

def _generate_subkeys(key_bytes: bytes) -> list[int]:
    """Produce the 52 x 16-bit encryption subkeys from a 128-bit key."""
    if len(key_bytes) != _KEY_BYTES:
        raise ValueError(f"IDEA key must be {_KEY_BYTES} bytes, got {len(key_bytes)}")

    # Represent key as a 128-bit integer for rotation
    key_int = int.from_bytes(key_bytes, "big")

    subkeys: list[int] = []
    while len(subkeys) < 52:
        # Extract up to 8 x 16-bit words from current key_int
        for i in range(7, -1, -1):
            if len(subkeys) >= 52:
                break
            subkeys.append((key_int >> (i * 16)) & _MASK16)
        # Rotate 128-bit key left by 25 bits
        key_int = ((key_int << 25) | (key_int >> (128 - 25))) & ((1 << 128) - 1)

    return subkeys


def _invert_subkeys(enc_keys: list[int]) -> list[int]:
    """Derive the 52 decryption subkeys from the encryption subkeys.

    Decryption runs the same MA-structure round function in reverse:
      - Dec round 1   : inverse of enc output transform + K5/K6 from enc round 8
      - Dec rounds 2–8: inverse of enc rounds 8...2 with K2/K3 swapped (undoes
                        the mid-block swap that occurs between enc rounds)
      - Dec out-xform : inverse of enc round 1, no swap
    """
    dec: list[int] = [0] * 52

    # Dec round 1: undo enc output transform (enc indices 48-51)
    dec[0] = _mul_inv(enc_keys[48])
    dec[1] = _add_inv(enc_keys[49])
    dec[2] = _add_inv(enc_keys[50])
    dec[3] = _mul_inv(enc_keys[51])
    # K5, K6 borrowed from enc round 8 (0-indexed round 7 -> indices 46, 47)
    dec[4] = enc_keys[46]
    dec[5] = enc_keys[47]

    # Dec rounds 2–8 (r = 1..7): undo enc rounds 8..2 (0-indexed 7..1)
    for r in range(1, 8):
        enc_base  = (8 - r) * 6          # enc round to undo (0-indexed)
        dec_base  = r * 6
        prev_base = (7 - r) * 6          # enc round supplying K5/K6

        dec[dec_base]     = _mul_inv(enc_keys[enc_base])
        dec[dec_base + 1] = _add_inv(enc_keys[enc_base + 2])  # K3 -> pos 2 (swap)
        dec[dec_base + 2] = _add_inv(enc_keys[enc_base + 1])  # K2 -> pos 3 (swap)
        dec[dec_base + 3] = _mul_inv(enc_keys[enc_base + 3])
        dec[dec_base + 4] = enc_keys[prev_base + 4]
        dec[dec_base + 5] = enc_keys[prev_base + 5]

    # Dec output transform: undo enc round 1 (no K2/K3 swap)
    dec[48] = _mul_inv(enc_keys[0])
    dec[49] = _add_inv(enc_keys[1])
    dec[50] = _add_inv(enc_keys[2])
    dec[51] = _mul_inv(enc_keys[3])

    return dec


# ---------------------------------------------------------------------------
# Block-level cipher
# ---------------------------------------------------------------------------

def _idea_block(x1: int, x2: int, x3: int, x4: int,
                subkeys: list[int]) -> tuple[int, int, int, int]:
    """Apply 8 IDEA rounds + output transformation to a 64-bit block."""

    for r in range(_ROUNDS):
        k = subkeys[r * 6 : r * 6 + 6]

        a = _mul(x1, k[0])
        b = _add(x2, k[1])
        c = _add(x3, k[2])
        d = _mul(x4, k[3])

        e = _mul(a ^ c, k[4])
        f = _add(b ^ d, e)
        g = _mul(f, k[5])
        h = _add(e, g)

        x1 = a ^ g
        x4 = d ^ h
        if r < _ROUNDS - 1:
            # Rounds 1-7: swap positions 2 and 3 (standard IDEA inter-round swap)
            x2 = c ^ g
            x3 = b ^ h
        else:
            # Round 8: no swap before the output transformation
            x2 = b ^ h
            x3 = c ^ g

    # Output transformation (subkeys 49–52, indices 48–51)
    k = subkeys[48:52]
    y1 = _mul(x1, k[0])
    y2 = _add(x2, k[1])
    y3 = _add(x3, k[2])
    y4 = _mul(x4, k[3])

    return y1, y2, y3, y4


# ---------------------------------------------------------------------------
# PKCS#7 helpers (shared with XTEA -- copied here to keep modules independent)
# ---------------------------------------------------------------------------

def _pad(data: bytes) -> bytes:
    pad_len = _BLOCK_BYTES - (len(data) % _BLOCK_BYTES)
    return data + bytes([pad_len] * pad_len)


def _unpad(data: bytes) -> bytes:
    if not data:
        raise ValueError("Empty data")
    pad_len = data[-1]
    if pad_len < 1 or pad_len > _BLOCK_BYTES:
        raise ValueError(f"Bad PKCS#7 padding byte: {pad_len}")
    if data[-pad_len:] != bytes([pad_len] * pad_len):
        raise ValueError("PKCS#7 padding corrupt")
    return data[:-pad_len]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

class IDEACipher:
    """IDEA symmetric cipher with CBC mode for arbitrary-length messages.

    Usage::

        cipher = IDEACipher(key_bytes_16)
        ciphertext = cipher.encrypt(b"Secret data")
        plaintext  = cipher.decrypt(ciphertext)
    """

    def __init__(self, key: bytes) -> None:
        self._enc_keys: list[int] = _generate_subkeys(key)
        self._dec_keys: list[int] = _invert_subkeys(self._enc_keys)

    # -- raw block (exposed for handwritten-example verification) --

    def encrypt_block_raw(self, x1: int, x2: int,
                          x3: int, x4: int) -> tuple[int, int, int, int]:
        """Encrypt one 64-bit block (four 16-bit sub-blocks)."""
        return _idea_block(x1, x2, x3, x4, self._enc_keys)

    def decrypt_block_raw(self, x1: int, x2: int,
                          x3: int, x4: int) -> tuple[int, int, int, int]:
        """Decrypt one 64-bit block."""
        return _idea_block(x1, x2, x3, x4, self._dec_keys)

    # -- CBC mode --

    def encrypt(self, plaintext: bytes) -> bytes:
        """Encrypt arbitrary plaintext.

        Returns: IV (8 bytes) || CBC-encrypted ciphertext.

        Time: O(n)   Space: O(n)
        """
        padded = _pad(plaintext)
        iv = os.urandom(_BLOCK_BYTES)
        prev = struct.unpack(">4H", iv)      # four 16-bit words
        blocks: list[bytes] = [iv]

        for i in range(0, len(padded), _BLOCK_BYTES):
            x1, x2, x3, x4 = struct.unpack(">4H", padded[i : i + _BLOCK_BYTES])
            # CBC XOR
            x1 ^= prev[0]; x2 ^= prev[1]; x3 ^= prev[2]; x4 ^= prev[3]
            y1, y2, y3, y4 = _idea_block(x1, x2, x3, x4, self._enc_keys)
            enc_block = struct.pack(">4H", y1, y2, y3, y4)
            blocks.append(enc_block)
            prev = (y1, y2, y3, y4)

        return b"".join(blocks)

    def decrypt(self, ciphertext: bytes) -> bytes:
        """Decrypt ciphertext produced by :meth:`encrypt`.

        Time: O(n)   Space: O(n)
        """
        if len(ciphertext) < _BLOCK_BYTES * 2:
            raise ValueError("Ciphertext too short")
        if len(ciphertext) % _BLOCK_BYTES != 0:
            raise ValueError("Ciphertext length must be multiple of 8 bytes")

        iv = ciphertext[:_BLOCK_BYTES]
        prev = struct.unpack(">4H", iv)
        result: list[bytes] = []

        for i in range(_BLOCK_BYTES, len(ciphertext), _BLOCK_BYTES):
            block = ciphertext[i : i + _BLOCK_BYTES]
            c1, c2, c3, c4 = struct.unpack(">4H", block)
            d1, d2, d3, d4 = _idea_block(c1, c2, c3, c4, self._dec_keys)
            # Undo CBC XOR
            p1 = d1 ^ prev[0]; p2 = d2 ^ prev[1]
            p3 = d3 ^ prev[2]; p4 = d4 ^ prev[3]
            result.append(struct.pack(">4H", p1, p2, p3, p4))
            prev = (c1, c2, c3, c4)

        return _unpad(b"".join(result))

    # -- file operations --

    def encrypt_file(self, input_path: str, output_path: str) -> int:
        """Encrypt a file at rest.  Returns ciphertext byte count."""
        with open(input_path, "rb") as fh:
            data = fh.read()
        ct = self.encrypt(data)
        with open(output_path, "wb") as fh:
            fh.write(ct)
        return len(ct)

    def decrypt_file(self, input_path: str, output_path: str) -> int:
        """Decrypt a file.  Returns plaintext byte count."""
        with open(input_path, "rb") as fh:
            ct = fh.read()
        pt = self.decrypt(ct)
        with open(output_path, "wb") as fh:
            fh.write(pt)
        return len(pt)


# ---------------------------------------------------------------------------
# Convenience
# ---------------------------------------------------------------------------

def generate_key() -> bytes:
    """Generate a random 128-bit IDEA key."""
    return os.urandom(_KEY_BYTES)

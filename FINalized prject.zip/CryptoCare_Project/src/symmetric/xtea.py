"""
XTEA -- eXtended Tiny Encryption Algorithm
==========================================
Designed by David Wheeler and Roger Needham (1997) as a correction to TEA.

Properties
----------
Block size : 64 bits  (two 32-bit words)
Key size   : 128 bits (four 32-bit words)
Rounds     : 64
Mode       : CBC with PKCS#7 padding (for multi-block messages)
Operations : XOR, addition mod 2^3^2, bit-shift only -- no S-boxes

Algorithm (one block)
---------------------
Encryption:
    DELTA = 0x9E3779B9   (golden ratio fractional part x 2^3^2)
    sum   = 0
    for i in 0..63:
        v0 += ( ((v1<<4) ^ (v1>>5)) + v1 ) ^ ( sum + key[sum & 3] )
        sum  = (sum + DELTA) mod 2^3^2
        v1 += ( ((v0<<4) ^ (v0>>5)) + v0 ) ^ ( sum + key[(sum>>11) & 3] )

Decryption reverses the loop with sum starting at DELTAx64 = 0xC6EF3720.

Complexity
----------
encrypt_block / decrypt_block : O(1)  -- fixed 64 rounds
encrypt / decrypt (n bytes)   : O(n)
encrypt_file / decrypt_file   : O(file_size)
Space                         : O(1) working state + O(n) output buffer
"""

from __future__ import annotations

import os
import struct
from typing import Union


_DELTA: int = 0x9E3779B9
_ROUNDS: int = 64
_BLOCK_BYTES: int = 8        # 64-bit block
_KEY_BYTES: int = 16         # 128-bit key
_MASK32: int = 0xFFFFFFFF
_SUM_INIT_DEC: int = (_DELTA * _ROUNDS) & _MASK32   # 0xC6EF3720


# ---------------------------------------------------------------------------
# Block-level primitives
# ---------------------------------------------------------------------------

def _encrypt_block(v0: int, v1: int, key: list[int]) -> tuple[int, int]:
    """Encrypt one 64-bit block.  key is a list of 4 unsigned 32-bit ints."""
    s = 0
    for _ in range(_ROUNDS):
        v0 = (v0 + ((((v1 << 4) ^ (v1 >> 5)) + v1) ^ (s + key[s & 3]))) & _MASK32
        s  = (s + _DELTA) & _MASK32
        v1 = (v1 + ((((v0 << 4) ^ (v0 >> 5)) + v0) ^ (s + key[(s >> 11) & 3]))) & _MASK32
    return v0, v1


def _decrypt_block(v0: int, v1: int, key: list[int]) -> tuple[int, int]:
    """Decrypt one 64-bit block."""
    s = _SUM_INIT_DEC
    for _ in range(_ROUNDS):
        v1 = (v1 - ((((v0 << 4) ^ (v0 >> 5)) + v0) ^ (s + key[(s >> 11) & 3]))) & _MASK32
        s  = (s - _DELTA) & _MASK32
        v0 = (v0 - ((((v1 << 4) ^ (v1 >> 5)) + v1) ^ (s + key[s & 3]))) & _MASK32
    return v0, v1


# ---------------------------------------------------------------------------
# Key parsing helpers
# ---------------------------------------------------------------------------

def _parse_key(key: bytes) -> list[int]:
    if len(key) != _KEY_BYTES:
        raise ValueError(f"XTEA key must be exactly {_KEY_BYTES} bytes, got {len(key)}")
    return list(struct.unpack(">4I", key))


def _parse_block(block: bytes) -> tuple[int, int]:
    v0, v1 = struct.unpack(">2I", block)
    return v0, v1


def _pack_block(v0: int, v1: int) -> bytes:
    return struct.pack(">2I", v0, v1)


# ---------------------------------------------------------------------------
# PKCS#7 padding
# ---------------------------------------------------------------------------

def _pad(data: bytes, block_size: int) -> bytes:
    pad_len = block_size - (len(data) % block_size)
    return data + bytes([pad_len] * pad_len)


def _unpad(data: bytes) -> bytes:
    if not data:
        raise ValueError("Empty ciphertext after stripping IV")
    pad_len = data[-1]
    if pad_len < 1 or pad_len > _BLOCK_BYTES:
        raise ValueError(f"Invalid PKCS#7 padding byte: {pad_len}")
    if data[-pad_len:] != bytes([pad_len] * pad_len):
        raise ValueError("PKCS#7 padding is corrupt")
    return data[:-pad_len]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

class XTEACipher:
    """XTEA symmetric cipher with CBC mode for arbitrary-length messages.

    Usage::

        cipher = XTEACipher(key_bytes_16)
        ciphertext = cipher.encrypt(b"Hello, world!")
        plaintext  = cipher.decrypt(ciphertext)
    """

    def __init__(self, key: bytes) -> None:
        self._key = _parse_key(key)

    # -- raw block operations (exposed for unit tests / handwritten examples) --

    def encrypt_block_raw(self, v0: int, v1: int) -> tuple[int, int]:
        """Encrypt a single 64-bit block given as two 32-bit integers."""
        return _encrypt_block(v0, v1, self._key)

    def decrypt_block_raw(self, v0: int, v1: int) -> tuple[int, int]:
        """Decrypt a single 64-bit block given as two 32-bit integers."""
        return _decrypt_block(v0, v1, self._key)

    # -- CBC mode --

    def encrypt(self, plaintext: bytes) -> bytes:
        """Encrypt plaintext bytes.

        Returns: IV (8 bytes) || ciphertext (padded to multiple of 8 bytes)

        Time: O(n)   Space: O(n)
        """
        padded = _pad(plaintext, _BLOCK_BYTES)
        iv = os.urandom(_BLOCK_BYTES)
        prev = _parse_block(iv)
        blocks: list[bytes] = [iv]

        for i in range(0, len(padded), _BLOCK_BYTES):
            b0, b1 = _parse_block(padded[i : i + _BLOCK_BYTES])
            # XOR with previous ciphertext (CBC chaining)
            b0 ^= prev[0]
            b1 ^= prev[1]
            enc = _encrypt_block(b0, b1, self._key)
            blocks.append(_pack_block(*enc))
            prev = enc

        return b"".join(blocks)

    def decrypt(self, ciphertext: bytes) -> bytes:
        """Decrypt ciphertext produced by :meth:`encrypt`.

        Time: O(n)   Space: O(n)
        """
        if len(ciphertext) < _BLOCK_BYTES * 2:
            raise ValueError("Ciphertext too short (must include IV + >=1 block)")
        if len(ciphertext) % _BLOCK_BYTES != 0:
            raise ValueError("Ciphertext length must be a multiple of 8 bytes")

        iv = ciphertext[:_BLOCK_BYTES]
        prev = _parse_block(iv)
        result: list[bytes] = []

        for i in range(_BLOCK_BYTES, len(ciphertext), _BLOCK_BYTES):
            block_bytes = ciphertext[i : i + _BLOCK_BYTES]
            c0, c1 = _parse_block(block_bytes)
            dec = _decrypt_block(c0, c1, self._key)
            # XOR with previous ciphertext to undo CBC
            p0 = dec[0] ^ prev[0]
            p1 = dec[1] ^ prev[1]
            result.append(_pack_block(p0, p1))
            prev = (c0, c1)

        return _unpad(b"".join(result))

    # -- file operations --

    def encrypt_file(self, input_path: str, output_path: str) -> int:
        """Encrypt a file.  Returns number of ciphertext bytes written."""
        with open(input_path, "rb") as fh:
            plaintext = fh.read()
        ciphertext = self.encrypt(plaintext)
        with open(output_path, "wb") as fh:
            fh.write(ciphertext)
        return len(ciphertext)

    def decrypt_file(self, input_path: str, output_path: str) -> int:
        """Decrypt a file.  Returns number of plaintext bytes recovered."""
        with open(input_path, "rb") as fh:
            ciphertext = fh.read()
        plaintext = self.decrypt(ciphertext)
        with open(output_path, "wb") as fh:
            fh.write(plaintext)
        return len(plaintext)


# ---------------------------------------------------------------------------
# Convenience functions
# ---------------------------------------------------------------------------

def generate_key() -> bytes:
    """Generate a random 128-bit XTEA key."""
    return os.urandom(_KEY_BYTES)

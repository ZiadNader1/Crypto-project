"""
Mathematical utilities for cryptographic operations.

All arithmetic is implemented from scratch using only Python built-ins
(no cryptographic libraries).  Algorithms used:
  - Miller-Rabin probabilistic primality test
  - Extended Euclidean algorithm for modular inverse
  - Fast modular exponentiation (built-in pow(b, e, m))
  - Safe-prime generation for ElGamal domain parameters

Complexity notes
----------------
is_prime(n, k)          : O(k · log^2n · log(log n))
generate_prime(bits)    : O(bits^3) expected (trial divisions + Miller-Rabin)
generate_safe_prime     : O(bits^3) expected (two prime tests per candidate)
mod_inverse             : O(log^2m)
find_generator          : O(p) worst-case, O(1) expected for safe primes
"""

from __future__ import annotations

import os
import random


# ---------------------------------------------------------------------------
# Primality testing
# ---------------------------------------------------------------------------

def is_prime(n: int, rounds: int = 20) -> bool:
    """Miller-Rabin probabilistic primality test.

    Error probability <= 4^(-rounds).  With rounds=20 this is ~10^-12.

    Time complexity: O(rounds · log^2n)
    """
    if n < 2:
        return False
    small_primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]
    for sp in small_primes:
        if n == sp:
            return True
        if n % sp == 0:
            return False

    # Write n-1 as 2^r · d with d odd
    r, d = 0, n - 1
    while d % 2 == 0:
        r += 1
        d //= 2

    for _ in range(rounds):
        a = random.randrange(2, n - 1)
        x = pow(a, d, n)            # built-in fast modular exponentiation
        if x in (1, n - 1):
            continue
        for _ in range(r - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False            # composite witness found
    return True


# ---------------------------------------------------------------------------
# Prime generation
# ---------------------------------------------------------------------------

def _random_odd(bits: int) -> int:
    """Return a random odd integer with exactly `bits` bits."""
    n = int.from_bytes(os.urandom((bits + 7) // 8), "big")
    n |= (1 << (bits - 1))         # set high bit
    n |= 1                          # ensure odd
    return n


def generate_prime(bits: int) -> int:
    """Generate a random prime with the given bit-length.

    Time complexity: O(bits^3) expected
    """
    while True:
        candidate = _random_odd(bits)
        if is_prime(candidate):
            return candidate


def generate_safe_prime(bits: int) -> tuple[int, int]:
    """Return (p, q) where p = 2q+1, both prime (Sophie Germain / safe prime).

    Safe primes simplify generator selection for ElGamal.

    Time complexity: O(bits^3) expected
    """
    while True:
        q = generate_prime(bits - 1)
        p = 2 * q + 1
        if is_prime(p, rounds=20):
            return p, q


# ---------------------------------------------------------------------------
# Extended Euclidean algorithm & modular inverse
# ---------------------------------------------------------------------------

def gcd(a: int, b: int) -> int:
    """Greatest common divisor via Euclidean algorithm.  O(log min(a,b))"""
    while b:
        a, b = b, a % b
    return a


def extended_gcd(a: int, b: int) -> tuple[int, int, int]:
    """Extended Euclidean: returns (g, x, y) s.t. a·x + b·y = g = gcd(a,b)."""
    if b == 0:
        return a, 1, 0
    g, x, y = extended_gcd(b, a % b)
    return g, y, x - (a // b) * y


def mod_inverse(a: int, m: int) -> int:
    """Modular multiplicative inverse of a mod m.

    Raises ValueError if the inverse does not exist (gcd(a,m) != 1).
    Time complexity: O(log^2m)
    """
    g, x, _ = extended_gcd(a % m, m)
    if g != 1:
        raise ValueError(f"Inverse of {a} mod {m} does not exist (gcd={g})")
    return x % m


# ---------------------------------------------------------------------------
# Modular exponentiation
# ---------------------------------------------------------------------------

def mod_pow(base: int, exp: int, mod: int) -> int:
    """Fast modular exponentiation using Python's built-in pow.

    Python's pow(b, e, m) uses the square-and-multiply algorithm internally.
    Time complexity: O(log e · log^2m)
    """
    return pow(base, exp, mod)


# ---------------------------------------------------------------------------
# Primitive root / generator finding
# ---------------------------------------------------------------------------

def find_generator(p: int, q: int) -> int:
    """Find a generator g of the subgroup of order q in Z_p*.

    Requires p = 2q + 1 (safe prime).
    A random g is a generator iff g^2 ≢ 1 (mod p) and g^q ≢ 1 (mod p).

    Expected iterations: O(1) since ~half of Z_p* elements are generators.
    """
    while True:
        g = random.randrange(2, p - 1)
        if pow(g, 2, p) != 1 and pow(g, q, p) != 1:
            return g


# ---------------------------------------------------------------------------
# Simple custom hash (no external library)
# ---------------------------------------------------------------------------

def simple_hash(data: bytes, digest_size: int = 32) -> bytes:
    """Deterministic hash function built from XOR, addition, and bit-rotation.

    NOT cryptographically secure -- used only for demonstration signatures.
    A production system would use SHA-256.

    Time complexity: O(|data| + digest_size)
    """
    state = bytearray(digest_size)
    for i, byte in enumerate(data):
        pos = i % digest_size
        state[pos] ^= byte
        state[(pos + 1) % digest_size] = (
            state[(pos + 1) % digest_size] + byte * (i + 1)
        ) % 256
        # Left-rotate by 1 bit
        carry = (state[pos] >> 7) & 1
        state[pos] = ((state[pos] << 1) | carry) & 0xFF

    # Three mixing passes to improve diffusion
    for _ in range(3):
        for i in range(digest_size):
            state[i] = (
                state[i]
                ^ state[(i + digest_size // 2) % digest_size]
                ^ state[(i + 1) % digest_size]
            ) & 0xFF
            state[i] = (state[i] + state[(i + 3) % digest_size]) % 256

    return bytes(state)


def hash_to_int(data: bytes, modulus: int) -> int:
    """Hash bytes to an integer in [1, modulus-1]."""
    raw = simple_hash(data, digest_size=64)
    value = int.from_bytes(raw, "big") % (modulus - 2)
    return value + 1                # guarantee non-zero

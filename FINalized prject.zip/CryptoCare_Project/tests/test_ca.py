"""Tests for Certificate Authority and certificate lifecycle."""

import time
import pytest

from src.ca.certificate_authority import Certificate, CertificateAuthority
from src.asymmetric.elgamal import generate_keys


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def ca() -> CertificateAuthority:
    return CertificateAuthority("Test-CA", key_bits=128)


@pytest.fixture(scope="module")
def entity_priv():
    return generate_keys(bits=128)


@pytest.fixture(scope="module")
def cert(ca, entity_priv) -> Certificate:
    return ca.issue_certificate("Alice", entity_priv.public_key, validity_days=30)


# ---------------------------------------------------------------------------
# Certificate issuance
# ---------------------------------------------------------------------------

class TestCertificateIssuance:
    def test_cert_has_correct_subject(self, cert):
        assert cert.subject == "Alice"

    def test_cert_has_correct_issuer(self, cert, ca):
        assert cert.issuer == ca.name

    def test_cert_has_serial(self, cert):
        assert cert.serial_number > 0

    def test_cert_has_signature(self, cert):
        assert cert.signature is not None

    def test_cert_valid_dates(self, cert):
        now = int(time.time())
        assert cert.valid_from <= now
        assert cert.valid_to > now

    def test_cert_contains_subject_pub_key(self, cert, entity_priv):
        from src.asymmetric.elgamal import public_key_from_dict
        pub = public_key_from_dict(cert.subject_pub_key)
        assert pub.y == entity_priv.public_key.y

    def test_serial_numbers_increment(self, ca, entity_priv):
        c1 = ca.issue_certificate("Bob", entity_priv.public_key)
        c2 = ca.issue_certificate("Carol", entity_priv.public_key)
        assert c2.serial_number > c1.serial_number


# ---------------------------------------------------------------------------
# Certificate verification
# ---------------------------------------------------------------------------

class TestCertificateVerification:
    def test_valid_certificate_passes(self, ca, cert):
        assert ca.verify_certificate(cert) is True

    def test_tampered_subject_fails(self, ca, cert):
        import copy
        tampered = copy.deepcopy(cert)
        tampered.subject = "Mallory"
        assert ca.verify_certificate(tampered) is False

    def test_tampered_pub_key_fails(self, ca, cert, entity_priv):
        import copy
        tampered = copy.deepcopy(cert)
        other_key = generate_keys(bits=128).public_key
        from src.asymmetric.elgamal import public_key_to_dict
        tampered.subject_pub_key = public_key_to_dict(other_key)
        assert ca.verify_certificate(tampered) is False

    def test_missing_signature_fails(self, ca, cert, entity_priv):
        import copy
        no_sig = copy.deepcopy(cert)
        no_sig.signature = None
        assert ca.verify_certificate(no_sig) is False

    def test_expired_certificate_fails(self, ca, entity_priv):
        cert = ca.issue_certificate("Expired", entity_priv.public_key, validity_days=1)
        # Manually set expiry to past
        cert.valid_to = cert.valid_from - 1
        assert ca.verify_certificate(cert) is False


# ---------------------------------------------------------------------------
# Revocation
# ---------------------------------------------------------------------------

class TestRevocation:
    def test_revoked_certificate_fails(self, ca, entity_priv):
        cert = ca.issue_certificate("Revoked", entity_priv.public_key)
        assert ca.verify_certificate(cert) is True
        ca.revoke_certificate(cert.serial_number)
        assert ca.verify_certificate(cert) is False

    def test_revoked_serial_in_list(self, ca, entity_priv):
        cert = ca.issue_certificate("RevTest", entity_priv.public_key)
        ca.revoke_certificate(cert.serial_number)
        assert cert.serial_number in ca.revoked_serials


# ---------------------------------------------------------------------------
# Certificate serialisation
# ---------------------------------------------------------------------------

class TestCertificateSerialization:
    def test_to_dict_from_dict_roundtrip(self, ca, cert):
        d = cert.to_dict()
        recovered = Certificate.from_dict(d)
        assert recovered.subject == cert.subject
        assert recovered.serial_number == cert.serial_number
        assert recovered.signature == cert.signature

    def test_recovered_cert_still_validates(self, ca, cert):
        d = cert.to_dict()
        recovered = Certificate.from_dict(d)
        assert ca.verify_certificate(recovered)

    def test_body_bytes_deterministic(self, cert):
        assert cert.body_bytes() == cert.body_bytes()

    def test_fingerprint_is_hex(self, cert):
        fp = CertificateAuthority.certificate_fingerprint(cert)
        assert all(c in "0123456789abcdef" for c in fp)

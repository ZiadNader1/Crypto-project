"""Tests for ElGamal asymmetric cipher and digital signatures."""

import pytest

from src.asymmetric.elgamal import (
    generate_keys,
    encrypt_int,
    decrypt_int,
    encrypt_session_key,
    decrypt_session_key,
    sign,
    verify,
    public_key_to_dict,
    public_key_from_dict,
    signature_to_dict,
    signature_from_dict,
    Ciphertext,
    PrivateKey,
    PublicKey,
)


# ---------------------------------------------------------------------------
# Fixtures  (use 128-bit keys for fast tests)
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def priv() -> PrivateKey:
    return generate_keys(bits=128)


@pytest.fixture(scope="module")
def pub(priv) -> PublicKey:
    return priv.public_key


# ---------------------------------------------------------------------------
# Key generation
# ---------------------------------------------------------------------------

class TestKeyGeneration:
    def test_generates_safe_prime(self, priv):
        # p = 2q+1 (both prime)
        from src.utils.math_utils import is_prime
        assert is_prime(priv.p)
        assert is_prime(priv.q)
        assert priv.p == 2 * priv.q + 1

    def test_generator_validity(self, priv, pub):
        from src.utils.math_utils import mod_pow
        # g^q ≢ 1 (mod p)  ->  g has order > 1
        assert mod_pow(pub.g, priv.q, priv.p) != 1

    def test_public_key_consistency(self, priv, pub):
        assert pub.y == pow(pub.g, priv.x, priv.p)

    def test_private_key_in_range(self, priv):
        assert 2 <= priv.x <= priv.q - 1


# ---------------------------------------------------------------------------
# Integer encryption / decryption
# ---------------------------------------------------------------------------

class TestIntegerEncryption:
    def test_round_trip(self, priv, pub):
        m = 42
        ct = encrypt_int(m, pub)
        assert decrypt_int(ct, priv) == m

    def test_large_message(self, priv, pub):
        m = pub.p - 2
        ct = encrypt_int(m, pub)
        assert decrypt_int(ct, priv) == m

    def test_message_zero_boundary(self, priv, pub):
        m = 1   # minimum valid value
        ct = encrypt_int(m, pub)
        assert decrypt_int(ct, priv) == m

    def test_invalid_message_too_large(self, pub):
        with pytest.raises(ValueError):
            encrypt_int(pub.p, pub)   # m must be < p

    def test_invalid_message_zero(self, pub):
        with pytest.raises(ValueError):
            encrypt_int(0, pub)

    def test_same_message_different_ciphertext(self, pub):
        m = 100
        ct1 = encrypt_int(m, pub)
        ct2 = encrypt_int(m, pub)
        # Probabilistic encryption: (c1,c2) almost certainly differs
        assert ct1 != ct2

    def test_wrong_key_gives_wrong_plaintext(self, pub):
        priv2 = generate_keys(bits=128)
        m = 7
        ct = encrypt_int(m, pub)
        recovered = decrypt_int(ct, priv2)
        assert recovered != m   # different private key -> wrong decryption


# ---------------------------------------------------------------------------
# Session key encryption
# ---------------------------------------------------------------------------

class TestSessionKey:
    def test_session_key_round_trip(self, priv, pub):
        import os
        sk = os.urandom(16)
        c1, c2 = encrypt_session_key(sk, pub)
        recovered = decrypt_session_key(c1, c2, priv)
        assert recovered == sk

    def test_wrong_length_raises(self, pub):
        with pytest.raises(ValueError):
            encrypt_session_key(b"short", pub)

    def test_different_keys_each_time(self, pub):
        import os
        sk = bytes(16)
        r1 = encrypt_session_key(sk, pub)
        r2 = encrypt_session_key(sk, pub)
        assert r1 != r2


# ---------------------------------------------------------------------------
# Digital signatures
# ---------------------------------------------------------------------------

class TestSignatures:
    def test_sign_and_verify(self, priv, pub):
        msg = b"Medical record authentication token"
        sig = sign(msg, priv)
        assert verify(msg, sig, pub)

    def test_tampered_message_fails(self, priv, pub):
        msg = b"original message"
        sig = sign(msg, priv)
        assert not verify(b"tampered message", sig, pub)

    def test_wrong_key_fails(self, priv):
        priv2 = generate_keys(bits=128)
        pub2 = priv2.public_key
        msg = b"auth"
        sig = sign(msg, priv)
        assert not verify(msg, sig, pub2)   # wrong public key

    def test_invalid_r_fails(self, pub):
        from src.asymmetric.elgamal import Signature
        sig = Signature(r=0, s=1)           # r=0 is invalid
        assert not verify(b"msg", sig, pub)

    def test_signature_differs_each_time(self, priv):
        msg = b"same message"
        s1 = sign(msg, priv)
        s2 = sign(msg, priv)
        # k is random -> different signatures
        assert s1 != s2

    def test_empty_message(self, priv, pub):
        sig = sign(b"", priv)
        assert verify(b"", sig, pub)


# ---------------------------------------------------------------------------
# Serialisation
# ---------------------------------------------------------------------------

class TestSerialisation:
    def test_public_key_roundtrip(self, pub):
        d = public_key_to_dict(pub)
        recovered = public_key_from_dict(d)
        assert recovered.p == pub.p
        assert recovered.y == pub.y

    def test_signature_roundtrip(self, priv):
        sig = sign(b"test", priv)
        d = signature_to_dict(sig)
        recovered = signature_from_dict(d)
        assert recovered == sig

"""Tests for IDEA symmetric cipher."""

import os
import struct
import tempfile
import pytest

from src.symmetric.idea import (
    IDEACipher,
    generate_key,
    _mul,
    _add,
    _mul_inv,
    _add_inv,
    _generate_subkeys,
    _invert_subkeys,
    _pad,
    _unpad,
    _BLOCK_BYTES,
    _KEY_BYTES,
    _MOD_MUL,
    _MOD_ADD,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def key() -> bytes:
    return generate_key()


@pytest.fixture
def cipher(key) -> IDEACipher:
    return IDEACipher(key)


# ---------------------------------------------------------------------------
# Group operations
# ---------------------------------------------------------------------------

class TestGroupOperations:
    def test_mul_zero_treated_as_65536(self):
        # 0 = 2^16 under IDEA multiplication
        # 0 ⊗ 0 = 2^16 * 2^16 mod 65537 = 2^32 mod 65537 = 1
        assert _mul(0, 0) == 1

    def test_mul_identity(self):
        assert _mul(1, 5) == 5
        assert _mul(5, 1) == 5

    def test_mul_commutativity(self):
        assert _mul(123, 456) == _mul(456, 123)

    def test_mul_result_zero_maps_to_zero(self):
        # If result == 65536, it is stored as 0
        # 65536 ⊗ 1 = 65536 mod 65537 = 65536 -> 0
        assert _mul(_MOD_ADD, 1) == 0

    def test_add_mod(self):
        assert _add(0xFFFF, 1) == 0    # wraps at 2^16
        assert _add(100, 200) == 300

    def test_add_inv_zero(self):
        assert _add_inv(0) == 0

    def test_add_inv_round_trip(self):
        for a in [0, 1, 100, 0x8000, 0xFFFF]:
            assert _add(_add_inv(a), a) == 0

    def test_mul_inv_one(self):
        assert _mul_inv(1) == 1

    def test_mul_inv_zero(self):
        assert _mul_inv(0) == 0

    def test_mul_inv_round_trip(self):
        for a in [1, 2, 3, 100, 257, 1000, 65536]:
            inv = _mul_inv(a)
            product = _mul(a, inv)
            assert product == 1, f"a={a} inv={inv} product={product}"


# ---------------------------------------------------------------------------
# Key schedule
# ---------------------------------------------------------------------------

class TestKeySchedule:
    def test_generates_52_subkeys(self):
        sk = _generate_subkeys(bytes(16))
        assert len(sk) == 52

    def test_all_subkeys_16bit(self):
        sk = _generate_subkeys(bytes(range(16)))
        assert all(0 <= k <= 0xFFFF for k in sk)

    def test_different_keys_different_subkeys(self):
        sk1 = _generate_subkeys(bytes(16))
        sk2 = _generate_subkeys(bytes(range(16)))
        assert sk1 != sk2

    def test_wrong_key_length_raises(self):
        with pytest.raises(ValueError):
            _generate_subkeys(bytes(8))

    def test_invert_subkeys_length(self):
        sk = _generate_subkeys(bytes(16))
        isk = _invert_subkeys(sk)
        assert len(isk) == 52


# ---------------------------------------------------------------------------
# Block-level correctness (handwritten example)
# ---------------------------------------------------------------------------

class TestBlockCipher:
    def test_encrypt_decrypt_zero_block(self, cipher):
        enc = cipher.encrypt_block_raw(0, 0, 0, 0)
        dec = cipher.decrypt_block_raw(*enc)
        assert dec == (0, 0, 0, 0)

    def test_encrypt_decrypt_arbitrary_block(self, cipher):
        block = (0x0001, 0x0002, 0x0003, 0x0004)
        enc = cipher.encrypt_block_raw(*block)
        dec = cipher.decrypt_block_raw(*enc)
        assert dec == block

    def test_handwritten_small_example(self):
        """Handwritten verification example using small key and block values.

        Key  : 16 zero bytes (K1..K8 all 0)
        Block: (1, 2, 3, 4)  -- four 16-bit sub-blocks
        Only round-trip correctness is checked here.
        """
        cipher = IDEACipher(bytes(16))
        block = (1, 2, 3, 4)
        enc = cipher.encrypt_block_raw(*block)
        dec = cipher.decrypt_block_raw(*enc)
        assert dec == block, f"Round-trip failed: {block} -> {enc} -> {dec}"

    def test_different_keys_give_different_output(self):
        c1 = IDEACipher(bytes(16))
        c2 = IDEACipher(bytes(range(16)))
        assert c1.encrypt_block_raw(1, 2, 3, 4) != c2.encrypt_block_raw(1, 2, 3, 4)


# ---------------------------------------------------------------------------
# CBC mode
# ---------------------------------------------------------------------------

class TestCBCMode:
    def test_short_message(self, cipher):
        pt = b"IDEA cipher!!"
        assert cipher.decrypt(cipher.encrypt(pt)) == pt

    def test_empty_message(self, cipher):
        assert cipher.decrypt(cipher.encrypt(b"")) == b""

    def test_exact_block_boundary(self, cipher):
        pt = b"B" * _BLOCK_BYTES
        assert cipher.decrypt(cipher.encrypt(pt)) == pt

    def test_multi_block(self, cipher):
        pt = os.urandom(128)
        assert cipher.decrypt(cipher.encrypt(pt)) == pt

    def test_large_message(self, cipher):
        pt = b"Medical record data. " * 100
        assert cipher.decrypt(cipher.encrypt(pt)) == pt

    def test_same_plaintext_different_ciphertext(self, cipher):
        pt = b"identical input!"
        assert cipher.encrypt(pt) != cipher.encrypt(pt)

    def test_ciphertext_too_short_raises(self, cipher):
        with pytest.raises(ValueError):
            cipher.decrypt(bytes(4))

    def test_wrong_key_fails(self):
        ct = IDEACipher(bytes(16)).encrypt(b"secret")
        with pytest.raises(Exception):
            IDEACipher(bytes(range(16))).decrypt(ct)


# ---------------------------------------------------------------------------
# Padding
# ---------------------------------------------------------------------------

class TestPadding:
    def test_pad_aligns(self):
        for length in range(25):
            padded = _pad(bytes(length))
            assert len(padded) % _BLOCK_BYTES == 0

    def test_pad_unpad_round_trip(self):
        for length in range(25):
            data = bytes(range(length % 256)) * (length // 256 + 1)
            data = data[:length]
            assert _unpad(_pad(data)) == data

    def test_unpad_bad_byte_raises(self):
        with pytest.raises(ValueError):
            _unpad(bytes(7) + b"\x09")    # pad_len=9 > block_size=8


# ---------------------------------------------------------------------------
# File operations
# ---------------------------------------------------------------------------

class TestFileEncryption:
    def test_file_round_trip(self, cipher):
        content = b"Patient blood test results: HbA1c=5.7%"
        with tempfile.NamedTemporaryFile(delete=False) as f:
            plain_path = f.name
            f.write(content)
        enc_path = plain_path + ".idea"
        dec_path = plain_path + ".dec"
        try:
            cipher.encrypt_file(plain_path, enc_path)
            cipher.decrypt_file(enc_path, dec_path)
            with open(dec_path, "rb") as fh:
                recovered = fh.read()
            assert recovered == content
        finally:
            for p in [plain_path, enc_path, dec_path]:
                if os.path.exists(p):
                    os.unlink(p)

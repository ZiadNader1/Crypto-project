"""Integration tests -- full end-to-end secure session and portal."""

import os
import tempfile
import pytest

from src.ca.certificate_authority import CertificateAuthority, Certificate
from src.app.secure_session import SecureServer, SecureClient
from src.app.healthcare_portal import HealthcarePortal
from src.pqc.lwe import (
    generate_keys as lwe_keys,
    encrypt_bytes,
    decrypt_bytes,
    generate_auth_token,
    verify_auth_token,
)
from src.utils.math_utils import is_prime, mod_inverse, simple_hash, hash_to_int


# ---------------------------------------------------------------------------
# Shared fixtures (module-scoped to reuse expensive key generation)
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def ca():
    return CertificateAuthority("Integration-CA", key_bits=128)


@pytest.fixture(scope="module")
def server(ca):
    return SecureServer("IntegServer", ca, key_bits=128)


@pytest.fixture(scope="module")
def client(ca):
    return SecureClient("IntegClient", ca, key_bits=128)


@pytest.fixture(scope="module")
def session_id(server, client):
    session_id = "test-sess-01"
    hello = client.initiate_handshake()
    client_cert = Certificate.from_dict(hello["client_cert"])
    server_hello = server.prepare_server_hello(client_cert, session_id)
    client.process_server_hello(server_hello)
    return session_id


# ---------------------------------------------------------------------------
# Handshake
# ---------------------------------------------------------------------------

class TestHandshake:
    def test_client_cert_is_valid(self, ca, client):
        assert ca.verify_certificate(client.certificate)

    def test_server_cert_is_valid(self, ca, server):
        assert ca.verify_certificate(server.certificate)

    def test_session_established(self, session_id):
        assert session_id == "test-sess-01"

    def test_invalid_cert_rejected(self, server, ca):
        """Server should reject a client with an invalid certificate."""
        bad_client = SecureClient("BadClient", ca, key_bits=128)
        ca.revoke_certificate(bad_client.certificate.serial_number)
        hello = bad_client.initiate_handshake()
        cert = Certificate.from_dict(hello["client_cert"])
        with pytest.raises(ValueError, match="INVALID"):
            server.prepare_server_hello(cert, "bad-session")


# ---------------------------------------------------------------------------
# Secure messaging (transit encryption)
# ---------------------------------------------------------------------------

class TestSecureMessaging:
    def test_client_to_server_round_trip(self, client, server, session_id):
        msg = b"Hello, hospital server!"
        ct = client.send_message(msg)
        recovered = server.receive_message(session_id, ct)
        assert recovered == msg

    def test_server_to_client_round_trip(self, client, server, session_id):
        msg = b"Your appointment is confirmed."
        ct = server.send_message(session_id, msg)
        recovered = client.receive_message(ct)
        assert recovered == msg

    def test_large_message_transit(self, client, server, session_id):
        msg = b"Radiology report: " + b"X" * 4000
        ct = client.send_message(msg)
        assert server.receive_message(session_id, ct) == msg

    def test_binary_data_transit(self, client, server, session_id):
        msg = os.urandom(256)
        ct = client.send_message(msg)
        assert server.receive_message(session_id, ct) == msg


# ---------------------------------------------------------------------------
# At-rest encryption (file storage)
# ---------------------------------------------------------------------------

class TestAtRestEncryption:
    def test_store_and_load_record(self, server, session_id):
        record = b"Patient: John Doe\nDiagnosis: Type-2 Diabetes\nHbA1c: 7.2%"
        with tempfile.NamedTemporaryFile(delete=False, suffix=".enc") as f:
            path = f.name
        try:
            server.store_record(session_id, record, path)
            assert os.path.exists(path)
            recovered = server.load_record(session_id, path)
            assert recovered == record
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def test_ciphertext_differs_from_plaintext(self, server, session_id):
        record = b"Sensitive data here"
        with tempfile.NamedTemporaryFile(delete=False, suffix=".enc") as f:
            path = f.name
        try:
            server.store_record(session_id, record, path)
            with open(path, "rb") as fh:
                ct = fh.read()
            assert ct != record
        finally:
            if os.path.exists(path):
                os.unlink(path)


# ---------------------------------------------------------------------------
# Healthcare portal (full integration)
# ---------------------------------------------------------------------------

class TestHealthcarePortal:
    def test_full_upload_download_cycle(self):
        portal = HealthcarePortal()
        patient = portal.register_client("Patient-Jane")
        sid = portal.connect(patient)

        content = b"Blood pressure: 118/76. Cholesterol: 180 mg/dL."
        path = portal.upload_record(patient, sid, "bp_record", content)
        assert os.path.exists(path)

        recovered = portal.download_record(patient, sid, path)
        assert recovered == content

    def test_pqc_authentication(self):
        portal = HealthcarePortal()
        doctor = portal.register_client("Doctor-Smith")
        assert portal.pqc_authenticate(doctor) is True

    def test_multiple_clients(self):
        portal = HealthcarePortal()
        patient = portal.register_client("Patient-A")
        doctor  = portal.register_client("Doctor-B")

        sid_p = portal.connect(patient)
        sid_d = portal.connect(doctor)

        msg_p = b"Patient note for doctor."
        msg_d = b"Doctor note for patient."

        path_p = portal.upload_record(patient, sid_p, "note_p", msg_p)
        path_d = portal.upload_record(doctor,  sid_d, "note_d", msg_d)

        assert portal.download_record(patient, sid_p, path_p) == msg_p
        assert portal.download_record(doctor,  sid_d, path_d) == msg_d


# ---------------------------------------------------------------------------
# Post-quantum module unit tests
# ---------------------------------------------------------------------------

class TestLWE:
    def test_key_generation(self):
        priv = lwe_keys()
        assert len(priv.s) == 16     # N=16
        assert len(priv.pub.a) == 16
        assert len(priv.pub.b) == 16

    def test_byte_encryption_round_trip(self):
        priv = lwe_keys()
        data = b"PQC test"
        ct = encrypt_bytes(data, priv.pub)
        assert decrypt_bytes(ct, priv) == data

    def test_auth_token_correct_user(self):
        priv = lwe_keys()
        token = generate_auth_token("alice", priv.pub)
        assert verify_auth_token(token, "alice", priv) is True

    def test_auth_token_wrong_user(self):
        priv = lwe_keys()
        token = generate_auth_token("alice", priv.pub)
        assert verify_auth_token(token, "bob", priv) is False

    def test_wrong_key_decryption_fails(self):
        priv1 = lwe_keys()
        priv2 = lwe_keys()
        ct = encrypt_bytes(b"secret", priv1.pub)
        recovered = decrypt_bytes(ct, priv2)
        assert recovered != b"secret"


# ---------------------------------------------------------------------------
# Math utilities
# ---------------------------------------------------------------------------

class TestMathUtils:
    def test_is_prime_known_primes(self):
        for p in [2, 3, 5, 7, 11, 97, 257, 65537]:
            assert is_prime(p), f"{p} should be prime"

    def test_is_prime_known_composites(self):
        for n in [1, 4, 6, 9, 15, 100, 65536]:
            assert not is_prime(n), f"{n} should be composite"

    def test_mod_inverse(self):
        assert mod_inverse(3, 7) == 5      # 3*5=15=1 mod 7
        assert mod_inverse(1, 11) == 1
        assert (mod_inverse(17, 3120) * 17) % 3120 == 1

    def test_mod_inverse_no_inverse_raises(self):
        with pytest.raises(ValueError):
            mod_inverse(2, 4)

    def test_simple_hash_deterministic(self):
        h1 = simple_hash(b"hello")
        h2 = simple_hash(b"hello")
        assert h1 == h2

    def test_simple_hash_different_inputs(self):
        assert simple_hash(b"hello") != simple_hash(b"world")

    def test_hash_to_int_in_range(self):
        m = 97
        for _ in range(10):
            v = hash_to_int(b"test", m)
            assert 1 <= v < m

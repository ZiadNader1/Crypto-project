"""
Network integration tests
=========================

Spins up a ``NetworkServer`` in a background daemon thread on a random
ephemeral port, then exercises the full protocol with one or more
``NetworkClient`` instances.

These tests use ``key_bits=128`` (the smallest safe-prime size our code
supports) so they complete in reasonable time while still exercising the
real cryptographic code paths.

Run with::

    cd project
    python -m pytest tests/test_network.py -v
"""

from __future__ import annotations

import os
import socket
import tempfile
import threading
import time

import pytest

from src.ca.certificate_authority import CertificateAuthority
from src.network.server import NetworkServer
from src.network.client import NetworkClient


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _free_port() -> int:
    """Find a free TCP port on localhost."""
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


# ---------------------------------------------------------------------------
# Module-scoped server fixture (start once, reuse across tests)
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def server_info():
    """Start a NetworkServer on a free port; yield (ca, host, port)."""
    port = _free_port()
    host = "127.0.0.1"
    bits = 192   # 192-bit: session key (128-bit) is always < p; fast enough

    storage = tempfile.mkdtemp(prefix="test_healthcare_net_")
    srv = NetworkServer(host=host, port=port, key_bits=bits, storage_dir=storage)

    ready = threading.Event()
    srv.start_background(ready_event=ready)
    ready.wait(timeout=10)   # wait until socket is bound

    yield srv.ca, host, port


# ---------------------------------------------------------------------------
# Convenience factory
# ---------------------------------------------------------------------------

def make_client(name: str, ca: CertificateAuthority, host: str, port: int) -> NetworkClient:
    return NetworkClient(name=name, ca=ca, host=host, port=port, key_bits=192)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestHandshake:
    """Verify that the TLS-style handshake + PQC auth succeed."""

    def test_connect_and_disconnect(self, server_info):
        ca, host, port = server_info
        client = make_client("TestPatient-A", ca, host, port)
        client.connect()
        assert client._session_id is not None
        client.disconnect()
        assert client._session_id is None

    def test_session_id_is_unique(self, server_info):
        ca, host, port = server_info
        c1 = make_client("TestPatient-B1", ca, host, port)
        c2 = make_client("TestPatient-B2", ca, host, port)
        c1.connect()
        c2.connect()
        assert c1._session_id != c2._session_id
        c1.disconnect()
        c2.disconnect()


class TestUploadDownload:
    """Verify end-to-end record upload and download."""

    def test_simple_round_trip(self, server_info):
        ca, host, port = server_info
        content = b"Blood pressure: 118/76.  Cholesterol: 180 mg/dL."
        with make_client("TestPatient-C", ca, host, port) as client:
            path = client.upload("bp_record", content)
            assert path.endswith(".enc")
            assert os.path.exists(path)
            recovered = client.download(path)
            assert recovered == content

    def test_large_record_round_trip(self, server_info):
        ca, host, port = server_info
        content = b"Radiology report: " + b"X" * 4000
        with make_client("TestPatient-D", ca, host, port) as client:
            path = client.upload("radiology", content)
            assert client.download(path) == content

    def test_binary_content_round_trip(self, server_info):
        ca, host, port = server_info
        content = os.urandom(256)
        with make_client("TestPatient-E", ca, host, port) as client:
            path = client.upload("binary_blob", content)
            assert client.download(path) == content

    def test_multiple_records(self, server_info):
        ca, host, port = server_info
        records = {
            "note_1": b"Note one: headache, mild fever.",
            "note_2": b"Note two: follow-up in 2 weeks.",
            "note_3": b"Note three: prescription renewed.",
        }
        with make_client("TestPatient-F", ca, host, port) as client:
            paths = {
                name: client.upload(name, data)
                for name, data in records.items()
            }
            for name, data in records.items():
                assert client.download(paths[name]) == data


class TestMultipleClients:
    """Two clients connect simultaneously with independent sessions."""

    def test_concurrent_sessions(self, server_info):
        ca, host, port = server_info

        results: dict[str, bytes] = {}
        errors:  list[Exception]  = []

        def run_client(name: str, data: bytes) -> None:
            try:
                with make_client(name, ca, host, port) as c:
                    path = c.upload("record", data)
                    results[name] = c.download(path)
            except Exception as exc:
                errors.append(exc)

        contents = {
            "ThreadClient-G1": b"Patient G1 data",
            "ThreadClient-G2": b"Patient G2 data",
        }

        threads = [
            threading.Thread(target=run_client, args=(name, data))
            for name, data in contents.items()
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=60)

        assert not errors, f"Thread errors: {errors}"
        for name, data in contents.items():
            assert results[name] == data, f"Mismatch for {name}"


class TestRevocation:
    """A client whose certificate is revoked should be rejected."""

    def test_revoked_client_rejected(self, server_info):
        ca, host, port = server_info
        client = make_client("BadClient-H", ca, host, port)

        # Revoke the cert BEFORE connecting
        ca.revoke_certificate(client._secure_client.certificate.serial_number)

        with pytest.raises((RuntimeError, ConnectionError, OSError)):
            client.connect()


class TestProtocol:
    """Unit tests for the protocol serialisation layer."""

    def test_bigint_round_trip(self):
        from src.network.protocol import encode_payload, decode_payload
        payload = {
            "p": 2**256 + 7,
            "nested": {"q": 2**128 - 1},
            "normal": "hello",
            "flag": True,
        }
        recovered = decode_payload(encode_payload(payload))
        assert recovered == payload

    def test_list_of_bigints(self):
        from src.network.protocol import encode_payload, decode_payload
        payload = {"key": [2**64, 2**128, 2**256]}
        assert decode_payload(encode_payload(payload)) == payload

    def test_bool_not_converted_to_bigint(self):
        from src.network.protocol import encode_payload, decode_payload
        payload = {"ok": True, "fail": False}
        recovered = decode_payload(encode_payload(payload))
        assert recovered["ok"] is True
        assert recovered["fail"] is False

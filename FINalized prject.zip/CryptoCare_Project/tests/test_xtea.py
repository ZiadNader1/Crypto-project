"""Tests for XTEA symmetric cipher."""

import os
import struct
import tempfile
import pytest

from src.symmetric.xtea import (
    XTEACipher,
    generate_key,
    _encrypt_block,
    _decrypt_block,
    _pad,
    _unpad,
    _BLOCK_BYTES,
    _KEY_BYTES,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def key() -> bytes:
    return generate_key()


@pytest.fixture
def cipher(key) -> XTEACipher:
    return XTEACipher(key)


# ---------------------------------------------------------------------------
# Key validation
# ---------------------------------------------------------------------------

class TestKeyValidation:
    def test_valid_key_accepted(self):
        XTEACipher(bytes(16))

    def test_short_key_raises(self):
        with pytest.raises(ValueError):
            XTEACipher(bytes(8))

    def test_long_key_raises(self):
        with pytest.raises(ValueError):
            XTEACipher(bytes(32))

    def test_generate_key_length(self):
        k = generate_key()
        assert len(k) == _KEY_BYTES


# ---------------------------------------------------------------------------
# Block-level correctness (handwritten example verification)
# ---------------------------------------------------------------------------

class TestBlockCipher:
    def test_encrypt_decrypt_zero_block(self, cipher):
        ct = cipher.encrypt_block_raw(0, 0)
        pt = cipher.decrypt_block_raw(*ct)
        assert pt == (0, 0)

    def test_encrypt_decrypt_known_block(self, cipher):
        """Verify encrypt followed by decrypt recovers the original values."""
        v0, v1 = 0x12345678, 0xABCDEF01
        enc = cipher.encrypt_block_raw(v0, v1)
        dec = cipher.decrypt_block_raw(*enc)
        assert dec == (v0, v1)

    def test_different_keys_produce_different_ciphertext(self):
        """Two different keys should produce different ciphertexts for same block."""
        key1 = bytes(range(16))
        key2 = bytes(range(1, 17))
        c1 = XTEACipher(key1).encrypt_block_raw(0x1111, 0x2222)
        c2 = XTEACipher(key2).encrypt_block_raw(0x1111, 0x2222)
        assert c1 != c2

    def test_handwritten_small_values(self):
        """Small-number example for handwritten verification.

        Key  : [1, 2, 3, 4]  (four 32-bit words)
        Block: v0=1, v1=2
        The test only checks round-trip correctness, not a fixed output,
        since XTEA's exact output depends on 64 rounds of complex mixing.
        """
        key_bytes = struct.pack(">4I", 1, 2, 3, 4)
        cipher = XTEACipher(key_bytes)
        enc = cipher.encrypt_block_raw(1, 2)
        dec = cipher.decrypt_block_raw(*enc)
        assert dec == (1, 2), f"Round-trip failed: got {dec}"


# ---------------------------------------------------------------------------
# CBC mode correctness
# ---------------------------------------------------------------------------

class TestCBCMode:
    def test_short_message(self, cipher):
        pt = b"Hello!"
        assert cipher.decrypt(cipher.encrypt(pt)) == pt

    def test_exact_block_boundary(self, cipher):
        pt = b"A" * _BLOCK_BYTES
        assert cipher.decrypt(cipher.encrypt(pt)) == pt

    def test_multi_block(self, cipher):
        pt = b"X" * 64
        assert cipher.decrypt(cipher.encrypt(pt)) == pt

    def test_empty_message(self, cipher):
        pt = b""
        assert cipher.decrypt(cipher.encrypt(pt)) == pt

    def test_single_byte(self, cipher):
        pt = b"\xFF"
        assert cipher.decrypt(cipher.encrypt(pt)) == pt

    def test_binary_data(self, cipher):
        pt = os.urandom(128)
        assert cipher.decrypt(cipher.encrypt(pt)) == pt

    def test_ciphertext_includes_iv(self, cipher):
        pt = b"test"
        ct = cipher.encrypt(pt)
        # IV is the first block
        assert len(ct) >= _BLOCK_BYTES * 2

    def test_identical_plaintexts_differ_in_ciphertext(self, cipher):
        """CBC with random IV: same plaintext -> different ciphertext each time."""
        pt = b"same message here!!"
        ct1 = cipher.encrypt(pt)
        ct2 = cipher.encrypt(pt)
        assert ct1 != ct2

    def test_wrong_key_fails(self):
        key1 = bytes(range(16))
        key2 = bytes(range(16, 32))
        ct = XTEACipher(key1).encrypt(b"secret data")
        with pytest.raises(Exception):      # ValueError (bad padding) expected
            XTEACipher(key2).decrypt(ct)

    def test_ciphertext_too_short_raises(self, cipher):
        with pytest.raises(ValueError):
            cipher.decrypt(bytes(4))

    def test_unaligned_ciphertext_raises(self, cipher):
        with pytest.raises(ValueError):
            cipher.decrypt(bytes(13))


# ---------------------------------------------------------------------------
# Padding helpers
# ---------------------------------------------------------------------------

class TestPadding:
    def test_pad_adds_full_block_when_aligned(self):
        data = bytes(_BLOCK_BYTES)
        padded = _pad(data, _BLOCK_BYTES)
        assert len(padded) == _BLOCK_BYTES * 2
        assert padded[-1] == _BLOCK_BYTES

    def test_round_trip_padding(self):
        for length in range(0, 24):
            data = bytes(length)
            padded = _pad(data, _BLOCK_BYTES)
            assert len(padded) % _BLOCK_BYTES == 0
            assert _unpad(padded) == data

    def test_unpad_invalid_byte_raises(self):
        with pytest.raises(ValueError):
            _unpad(bytes(7) + bytes([9]))   # pad_len=9 > block_size=8


# ---------------------------------------------------------------------------
# File encryption
# ---------------------------------------------------------------------------

class TestFileEncryption:
    def test_encrypt_decrypt_file(self, cipher):
        content = b"Patient record: blood pressure 120/80."
        with tempfile.NamedTemporaryFile(delete=False) as f:
            plain_path = f.name
            f.write(content)
        enc_path = plain_path + ".xtea"
        dec_path = plain_path + ".dec"
        try:
            n_ct = cipher.encrypt_file(plain_path, enc_path)
            n_pt = cipher.decrypt_file(enc_path, dec_path)
            with open(dec_path, "rb") as fh:
                recovered = fh.read()
            assert recovered == content
            assert n_pt == len(content)
        finally:
            for p in [plain_path, enc_path, dec_path]:
                if os.path.exists(p):
                    os.unlink(p)

    def test_ciphertext_larger_than_plaintext(self, cipher):
        content = b"short"
        with tempfile.NamedTemporaryFile(delete=False) as f:
            plain_path = f.name
            f.write(content)
        enc_path = plain_path + ".enc"
        try:
            n_ct = cipher.encrypt_file(plain_path, enc_path)
            assert n_ct > len(content)   # IV + padding overhead
        finally:
            for p in [plain_path, enc_path]:
                if os.path.exists(p):
                    os.unlink(p)
